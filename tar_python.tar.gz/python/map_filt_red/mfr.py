#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
#Usage="Usage: "
#if len(sys.argv) != 2 : 
#	print(Usage)
#	exit(1)
#arg1=sys.argv[1]
#
l1=[1,2,3]
l2=[4,5,6]
m=map(lambda x:float(x),l1)
print("map=",list(m))
f=filter(lambda x: x%2==0,l2)
print(list(f))
r=reduce(lambda x,y:x+y,l2)
print(r)
