#!/usr/bin/python3
import os,sys,re
def Plane_move(pos,move):
	print('***********************')
	direction=list(move).pop()
	print('direction ',direction)
	dist=move[:-1]
	if len(dist) == 0:
		dist=1
	else:
		dist=int(dist)
	print('dist ',dist)
	print('curr_position is ',pos)
	if direction == 'U':
		pos[0]+=dist
	elif direction == 'D':
			pos[0]-=dist
	elif direction == 'L':
			pos[1]-=dist
	elif direction == 'R':
			pos[1]+=dist
	else:
		print('ERROR on move syntax...exiting')
		exit(0)
	print('new position is ',pos)
	return(pos)
pat_cmd=re.compile('(\d*\w)')
pos=[0,0]
while True:
	move_str=input('Enter the move cmd > ').strip().upper()
	if move_str[0] == 'Q' or move_str[0] == 'q':exit(0)
	print(move_str)
	move_lst=re.findall(pat_cmd,move_str)
	print('input move is ',tuple(move_lst))
	for i in move_lst:
		pos=Plane_move(pos,i)
		print('position is ',pos)
