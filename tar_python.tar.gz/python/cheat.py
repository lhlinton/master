#!/usr/bin/python3
import re,os,sys
import string,os.path,subprocess
patip=re.compile('ip')
pataddr=re.compile('\d+(\.\d+){3}')
with open('cpout_lhl','r') as f:
	lines=f.read().splitlines()
print("lines in the file = ",len(lines))
for l in lines:
	tokens=re.split('\s+',l)
	if re.match(patip,tokens[0]):
		print(tokens[0])
		print(tokens[2])
		if re.match(pataddr,tokens[2]):
			print(tokens[2])
			break
