#!/usr/bin/python3
def abc():
	print('a')
	def b():
		print('b')

@abc
def x():
	abc()
	print('x')
x()
