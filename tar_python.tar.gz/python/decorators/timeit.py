#!/usr/bin/python3
from time import time
def twrap(func,arg):
	t1=time()
	func(arg)
	t2=time()
	print(t2-t1,' secs')

@twrap
twrap(sleep,3)
