#!/usr/bin/python3
def abc(func,cp):
	print('abc')
	print('cp')
	def b(s):
		print('b')
		print(s)
		func(s)
		return()
	return(b)

@abc('cutie pie')
def x(k):
	print('Inside x')
	print(k)

x('Kilroy was here')
