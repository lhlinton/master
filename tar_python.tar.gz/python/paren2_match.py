#!/usr/bin/python3
import sys
stak=[]
#str='(a) realyy 3 (std) (cloaked(red)))'
#str='((a realyy 3 (std) (cloaked(red)))'
#str='(a realyy 3 (std) (cloaked(red)))'
#str='(a [r]ealyy 3 (std) (cloaked(red)))'
if len(sys.argv) != 2:
	print("Usage: <cmd> <str>");exit()
str=sys.argv[1]
opens='([<'
closes=')]>'
mydict=dict(zip(closes,opens))
print('input str, len of input str:',str,len(str))
for c in str:
	if opens.count(c) is not 0:
		stak.append(c)
	elif closes.count(c) is not 0:
		if len(stak) > 0:
			if stak.pop() == mydict.get(c):
				pass
		else:
			print('failed too many closes')
			exit()
	else:
		pass
if len(stak) == 0:
	print('matched')
else:
		print('failed too many opens')
