#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from collections import OrderedDict
from operator import itemgetter
print('0123456789'*5)
s='(a realyy 3 (std) (cloaked(red)))'
print(s)
print(s.count('('),'opens,',s.count(')'),'closes')
l=[]
print('len of s=',len(s))
for i in range(len(s)):
	if s[i] == '(':l.append(i);print(i)
	if s[i] == ')':l.pop();print('matched at ',i)
""" OUTPUT
01234567890123456789012345678901234567890123456789
(a realyy 3 (std) (cloaked(red)))
4 opens, 4 closes
len of s= 33
0
12
matched at  16
18
26
matched at  30
matched at  31
matched at  32
"""
