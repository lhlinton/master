#!/usr/bin/python3
import cProfile
def fac(n):
	if n == 0 or n == 1:return(1)
	return(n*fac(n-1))
def perms(n,m):
	return(int(fac(n)/fac(n-m)))
def getperms(l,l2,depth,count):
	k=range(len(l))
	k2=len(l2)
	if k2 == depth:
		count+=1
		print('**********RESULT:',count,l2)
		l2.pop()
		return()
	for i in l:
		if i not in l2:
			l2.append(i)
			getperms(l,l2,depth,count)
	if len(l2) > 0:l2.pop()
n=4;m=2
trees=4;depth=2
l=[i for i in range(1,trees+1)]
count=0
l2=[]
depth=2
cProfile.run('fac(n)')
cProfile.run('perms(n,m)')
cProfile.run('getperms(l,l2,depth,count)')
