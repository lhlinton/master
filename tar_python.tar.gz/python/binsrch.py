#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from collections import OrderedDict
from operator import itemgetter
def binsrch(num,ls):
	lslen=len(ls)
	start=0;end=lslen-1;mid=(end-start)//2
	count=0
	while end-start > 1:
		if ls[mid] == num:return(mid)
		if ls[mid] <num:
			start=mid
		else:
			end=mid
		mid=start+(end-start)//2
	if ls[start] == num:return(start)
	if ls[end] == num:return(end)
	return(-1)
l=[8,1,7,2,6,3,5,4]
ls=sorted(l)
lslen=len(ls)
print(l)
print(ls)
print(lslen)
for num in range(1,lslen+1):
	index=binsrch(num,ls)
	print('ANS:num,index=',ls[index],index)
