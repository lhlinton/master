#!/usr/bin/python3
import sys,os,re
head=None
class LL:
	def __init__(self,num):
		global head
		self.num=num
		self.next=None
		if head is None:head=self
	def app(self,num):
		global head
		newnode=LL(num)
		nextptr=head
		while nextptr.next is not None:
			nextptr=nextptr.next
		nextptr.next=newnode
		return()
	def pr(self):
		global head
		nextptr=head
		if head is None:print('headis none')
		while nextptr is not None:
			print("nodeval = ",nextptr.num)
			nextptr=nextptr.next
n=LL(1)
n.pr()
n.app(2)
n.pr()
n.app(4)
n.pr()
