#!/usr/bin/python
# Hello world python program
import os
print "Hello World!";
z=["a","b","c"]
xx={}
xx[0]="fred"
print xx
print xx[0]
print z
print z[2]
x=z
print x
q=os.environ['SHELL']
print q
# ERR NO GET q=os.environ.get['SHELL']
print q
print "done"
