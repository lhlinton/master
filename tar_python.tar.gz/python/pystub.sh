#!/bin/bash
touch $1
chmod a+x $1
echo $1
cat /home/lee/pystub >> $1
vi +\$ $1
