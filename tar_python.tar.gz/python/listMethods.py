#!/usr/bin/python3
import string,sys
for i in dir(sys.argv[1]):
	if i[0].isalpha():print(i,end=' ')
print()
