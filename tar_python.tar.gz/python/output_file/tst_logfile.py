#!/usr/bin/python3
import datetime
with open('log','w+') as log:
	for i in range(10):
		ts=str(datetime.datetime.now())
		msg=ts+' '+str(i)+'\n'
		log.write(msg)
log.close
