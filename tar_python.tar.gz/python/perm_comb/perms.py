#!/usr/bin/python3

def factorial(n):
  if(n==0):return 1
  qed = n
  while n != 1:
    qed = qed * (n - 1)
    n = n - 1
  return qed

def get_permutations(n,r):
# no. of permutations(order dependent)
# = n items  taken r at a time or ( n! / ((n-r)! * r!))
  return int( factorial(n) / factorial(n - r) )
n,r=input('enter <n> <r> (n numbers taken r at a time) > ').split()
n=int(n)
r=int(r)
print('no. of perms = ',get_permutations(n,r))
