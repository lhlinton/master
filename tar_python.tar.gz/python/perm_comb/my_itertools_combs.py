def get_comb_list(inlst,r):
	outlst=[]
	ptrlst=[]
	print(inlst)
	last=len(inlst)-1
	ncombs=get_combinations(len(inlst),r)
	print("ncombs=",ncombs)
	for i in range(r):
		ptrlst.append(i)
	print(ptrlst)
	for i in range(ncombs):
		tmptuple=()
		for j in range(r):
			tmptuple+=(inlst[ptrlst[j]],)
		outlst.append(tmptuple)
		last=len(inlst)-1
		for k in range(r-1,-1,-1):
			if ptrlst[k] < last:
				if k<r-1 and ptrlst[k+1]-ptrlst[k]==1: continue
				ptrlst[k]+=1
				break
			else:
				if ptrlst[k]-ptrlst[k-1] > 1:
					ptrlst[k-1]+=1
					if ptrlst[k]-ptrlst[k-1] > 1:
						ptrlst[k]-=1
					break
				else:
					if ptrlst[k]-ptrlst[k-1] > 1:
						ptrlst[k-1]+=1
						break
					else:
						continue
	return outlst
