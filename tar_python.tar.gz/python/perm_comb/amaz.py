#!/usr/bin/python3
import sys,os,re
import re

def factorial(n):
	qed = n
	while n != 1:
		qed = qed * (n - 1)
		n = n - 1
	return qed

def get_combinations(n,r):
# no. of combinations(order independent)
# = n items  taken 2 at a time or ( n! / ((n-r)! * r!))
	return int( (factorial(n) / ((factorial(n - r)) * factorial(r))) )

nproblems=2
int_input_arr1=[5,5,15,10]
int_input_arr2=[1,2,3,4]
input_arrays=[int_input_arr1,int_input_arr2]
target_sums=[15,6]
for prob in range(nproblems):
	answer_lst=[]
	print("PROBLEM",prob)
	tmplst=input_arrays[prob]
	print("There are", len(tmplst), "values to test")
	print(tmplst)
	num_tests = get_combinations(len(tmplst), 2)
	print("num_tests=",num_tests)
	test_array = [[0 for x in range(2)] for x in range(num_tests)]
	test_index = 0
	for i in range(len(tmplst)-1):
		for j in range(i + 1, len(tmplst)):
			test_array[test_index][0] = tmplst[i]
			test_array[test_index][1] = tmplst[j]
			print(test_index,i,j)
			test_index+=1
	print("Test Matrix",test_index)
	for test_index in range(num_tests):
		print(test_array[test_index][0], test_array[test_index][1])
		if(test_array[test_index][0] + test_array[test_index][1] == target_sums[prob]):
			print(test_array[test_index][0],test_array[test_index][1])
			answer_lst.append([test_array[test_index][0],test_array[test_index][1]])
	print("PROBLEM",prob+1,"TARGET SUM=",target_sums[prob])
	print(answer_lst)
