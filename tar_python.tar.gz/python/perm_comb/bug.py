#!/usr/bin/python3
import sys
import os
import subprocess
import re
def factorial(n):
  qed = n
  while n != 1:
    qed = qed * (n - 1)
    n = n - 1
  return qed
def get_combinations(n,r):
# no. of combinations(order independent)
# = n items  taken 2 at a time or ( n! / ((n-r)! * r!))
  return int( (factorial(n) / ((factorial(n - r)) * factorial(r))) )
#int_input_arr=[5,5,15,10]
int_input_arr=[1,2,3,4]
print("There are", len(int_input_arr), "values to test")
print(int_input_arr)
num_tests = get_combinations(len(int_input_arr), 2)
print("num_tests=",num_tests)
test_array = [[0 for x in range(2)] for x in range(num_tests)]
test_index = 0
for test_index in range(len(int_input_arr)-1):
  for j in range(test_index + 1, len(int_input_arr)):
    test_array[test_index + j - 1][0] = int_input_arr[test_index]
    test_array[test_index + j - 1][1] = int_input_arr[j]
    print(test_index,j,int_input_arr[test_index],int_input_arr[j])
    print(test_array[test_index + j - 1][0], test_array[test_index + j - 1][1])
print("Test Matrix")
for test_index in range(len(int_input_arr)-1):
  for j in range(test_index + 1, len(int_input_arr)):
    print(test_index,j)
    print(test_array[test_index + j - 1][0], test_array[test_index + j - 1][1])
