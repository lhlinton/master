#!/usr/bin/python3
import sys,os,re
import itertools

def factorial(n):
	if(n==0):return 1
	qed = n
	while n != 1:
		qed = qed * (n - 1)
		n = n - 1
	return qed

def get_combinations(n,r):
# no. of combinations(order independent)
# = n items  taken 2 at a time or ( n! / ((n-r)! * r!))
	return int( (factorial(n) / ((factorial(n - r)) * factorial(r))) )

nproblems=2
int_input_arr1=[5,5,15,10]
int_input_arr2=[1,2,3,4]
input_arrays=[int_input_arr1,int_input_arr2]
target_sums=[15,6]
for prob in range(nproblems):
	answer_lst=[]
	print("PROBLEM",prob+1,"target sum =",target_sums[prob])
	for n in range(1,len(input_arrays[prob])+1): #n is for items taken n ata time
		for j in itertools.combinations(input_arrays[prob],n): #each comb for nitems
			answer_lst.append(j)
	len_ans=len(answer_lst)
	print(answer_lst) 
	print("length of above list is",len_ans)
###
	for i in range(len_ans):
		sum=0
		for j in range(len(answer_lst[i])):
			sum+=answer_lst[i][j]
		if sum == target_sums[prob]:
			print(answer_lst[i])
