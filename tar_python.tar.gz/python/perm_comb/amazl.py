#!/usr/bin/python3
import itertools
lee=[]
stuff=[1,2,3,4]
for L in range(1, len(stuff)+1):
	for subset in itertools.combinations(stuff, L):
		lee.append(subset)
print(lee)
print("*******")
print(lee[0])
print(len(lee[0]))
print(lee[13])
print(lee[13][0],lee[13][1],lee[13][2])
print(len(lee))
