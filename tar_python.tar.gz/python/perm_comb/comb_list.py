#!/usr/bin/python3
import sys,os,re
import itertools

def factorial(n):
	if(n==0):return 1
	qed = n
	while n != 1:
		qed = qed * (n - 1)
		n = n - 1
	return qed

def get_combinations(n,r):
# no. of combinations(order independent)
# = n items  taken 2 at a time or ( n! / ((n-r)! * r!))
	return int( (factorial(n) / ((factorial(n - r)) * factorial(r))) )

def get_comb_list(inlst,r):
	outlst=[]
	ptrlst=[]
	print(inlst)
	last=len(inlst)-1
	ncombs=get_combinations(len(inlst),r)
	print("ncombs=",ncombs)
	for i in range(r):
		ptrlst.append(i)
	print(ptrlst)
	for i in range(ncombs):
		tmptuple=()
		for j in range(r):
			tmptuple+=(inlst[ptrlst[j]],)
		outlst.append(tmptuple)
		print("DBG1:outlst:",outlst)
		print("DBG2:ptrlst:",ptrlst)
		ptr_moved=False
		last=len(inlst)-1
		for k in range(r-1,-1,-1):
			print("DBG3:ptrlst,k:",ptrlst,k)
			if ptrlst[k] < last:
				ptrlst[k]+=1
				print("DBG5:< last,k:",last,k,ptrlst)
				ptr_moved=True
				break
			else:
				if ptrlst[k]-ptrlst[k-1] > 1:
					ptrlst[k-1]+=1
					ptr_moved=True
					print("DBG5.1,last,k,ptrlst:",last,k,ptrlst)
					break
				else:
					print("DBG5.25:>= last")
					if ptrlst[k]-ptrlst[k-1] > 1:
						ptrlst[k-1]+=1
						ptr_moved=True
						break
					else:
						print("DBG5.5")
						continue
			print("DBG6:",ptr_moved)
	return outlst

nproblems=2
int_input_arr1=[5,5,15,10]
int_input_arr2=[1,2,3,4]
r=2
input_arrays=[int_input_arr1,int_input_arr2]
l=get_comb_list(int_input_arr2,r)
print(l)
