#!/usr/bin/python3
import re,os,sys
from functools import reduce
l=[4,6,8]
[ l.append(i) for i in range(10,20,2)]
print(l)
l.insert(0,1)
print(l)
l.append(100)
print(l)
l.pop(0)
print(l)
l.pop(-1)
print(l)
"""
[4, 6, 8, 10, 12, 14, 16, 18]
[1, 4, 6, 8, 10, 12, 14, 16, 18]
[1, 4, 6, 8, 10, 12, 14, 16, 18, 100]
[4, 6, 8, 10, 12, 14, 16, 18, 100]
[4, 6, 8, 10, 12, 14, 16, 18]
"""
