#!/usr/bin/python3
import re,string
def google(*args):
	nump=len(args)
	print('num of args = ',nump)
	ans=args[0]
	for i in range(1,nump):
		pire=re.compile('(\{'+str(i-1)+'\})')
		ans=pire.sub(args[i],ans)
	print('answer=',ans)
google("I am a {0} {1}", "happy", "cat")
