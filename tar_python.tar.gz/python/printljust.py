#!/usr/bin/python3
import string
x='groceries'
v='crap'
y=2.22222
z=3.33333
print(y,z)
y='%0.2f'%(y)
z='%0.2f'%(z)
print(y,z)
y=str(y)
z=str(z)
print(y,z)
print(x.ljust(15),end='   ')
print(y.ljust(15),end='   ')
print(z.ljust(15))
print(v.ljust(15),end='   ')
print(y.ljust(15),end='   ')
print(z.ljust(15))
