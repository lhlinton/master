#!/usr/bin/python3
a=2;b=1;c=0
if b>a: print('t') 
else: print('f')
