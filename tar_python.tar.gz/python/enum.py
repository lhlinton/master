#!/usr/bin/python3
class DICT:
  KEY,VAL=range(2)
print(DICT.KEY,DICT.VAL)
