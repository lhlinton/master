#!/usr/bin/python3
l=['a','b','c']
hdrs=','.join('"{}"'.format(i) for i in l)
print(hdrs)
