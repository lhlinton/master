#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
#Usage="Usage: "
#if len(sys.argv) != 2 : 
#	print(Usage)
#	exit(1)
#arg1=sys.argv[1]
l=['a','b','c']
s=','.join('"' + elem + '"' for elem in l)
print(s)
