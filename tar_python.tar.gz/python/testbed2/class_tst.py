#!/usr/bin/python3
class test:
	def __init__(self,x):
		self.x=x
		self.y='z'
	def pr(self):
		print(self.x,self.y)
lee=test('l')
fred=test('f')
lee.pr()
fred.pr()
"""
OUTPUT:
l z
f z
"""
