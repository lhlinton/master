#!/usr/bin/python3
s=input('enter a string: ')
print(s)
l=[]
for i in s:
	if s.count(i) == 1: l.append(i)
print(l)
