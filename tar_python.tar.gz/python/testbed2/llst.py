#!/usr/bin/python3
class lnknode:
	def __init__(self,num):
		self.num=num
		self.next=None
class lnklst:
	def __init__(self):
		self.head=None
	def app(self,num):
		newnode=lnknode(num)
		if self.head is None: self.head=newnode; return()
		nextptr=self.head
		while nextptr.next is not None:
			nextptr=nextptr.next
		nextptr.next=newnode
		return()
	def pr(self):
		nextptr=self.head
		if nextptr is None:print('headis none');exit(0)
		while nextptr is not None:
			print('nodeval is', nextptr.num)
			nextptr=nextptr.next
n=lnklst()
n.app(2)
n.pr()
print()
n.app(3)
n.pr()
print()
n.app(4)
n.pr()
print()
m=lnklst()
m.app(28)
m.pr()
print()
