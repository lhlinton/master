#!/usr/bin/python3
import sys
def fib(n):
	a=0;b=1
	if n < 3:
		print("n must be > 2");return
	yield 0
	yield 1
	for i in range(3,n+1):
		a,b=b,a+b
		yield b
if len(sys.argv) == 2:
	print('input arg is ',sys.argv[1])
	print(list(fib(5)))
else:
	print(" Usage: <cmd> <no. of fibonacci integers to sequence> ")  
	exit(0)
