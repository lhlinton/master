#!/usr/bin/python3
import sys
if len(sys.argv) is not 3:
	print("Usage: <cmd> <string> <search val>")
	exit()
inp=sys.argv[1]
sval=sys.argv[2]
lst=sorted(iter(inp))
print('input,len, search val:',lst,len(lst),sval)
l=len(lst)
if l < 2:
	print('input must be > 1 char')
	exit()
lo=0;hi=l-1
loopcnt=0
for i in range(int(l/2)):
	loopcnt+=1
	mid=lo+int((hi-lo)/2)
	if lst[mid] == sval:
	elif lst[mid] > sval:
		hi=mid
	else:
		lo=mid
if hi == mid and lst[lo] == sval:print('hit on lo',lo);exit()
if lo == mid and lst[hi] == sval:print('hit on hi',hi);exit()
print('NOT found')
