#!/usr/bin/python3
class stak():
	def __init__(self):
		self.l=[]
	def push(self,n):
		self.l.append(n)
		return(len(self.l))
	def pop(self):
		if len(self.l) == 0:
			print('empty stak')
			return(0,0)
		self.x=self.l.pop()
		self.cnt=len(self.l)
		return(self.x,self.cnt)
	def mxval(self):
		if len(self.l) == 0:
			print('empty stak')
			return(-1)
		return(max(self.l))
	def getstak(self):
		if len(self.l) == 0:
			print('empty stak')
		return(self.l)
mystak=stak()
print(mystak.push(17))
x,y=mystak.pop()
print('popval,staklen= ',x,y)
print(mystak.push(17))
print(mystak.push(18))
print(mystak.push(19))
print(mystak.mxval())
print(mystak.getstak())
print('done')
