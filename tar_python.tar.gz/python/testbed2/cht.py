#!/usr/bin/python3
import re
fn='cpo'
with open(fn,'r') as f:
	lines=f.read().splitlines()
print('chk 1')
patip=re.compile('ip')
pataddr=re.compile('\d+(\.\d+){3}')
print('chk2')
print('lines in file = ',len(lines))
for l in lines:
	tokens=re.split('\s+',l)
	if re.match(patip,tokens[0]):
		print('ip match ',tokens[0])
		print('ipaddr ',tokens[2],end='')
		if re.match(pataddr,tokens[2]):print(' ',tokens[2])
