#!/usr/bin/python3
from operator import itemgetter,attrgetter
class Student:
	def __init__(self,name,grade,age):
		self.name=name
		self.grade=grade
		self.age=age
hank=Student('Hank','C',33)
lee=Student('Lee','A',71)
anne=Student('Anne','B',70)
print(lee.name)
print(sorted([hank,lee,anne],key=itemgetter(2)))
