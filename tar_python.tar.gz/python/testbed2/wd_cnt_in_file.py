#!/usr/bin/python3
import re
from operator import itemgetter
from collections import defaultdict,OrderedDict
dd=defaultdict(int)
with open('word_count_input_file.txt','r') as f:
	lines=f.read().splitlines()
lcnt=0
for l in lines:
	lcnt+=1
	tokens=re.split('\s+',l)
	for i in tokens:
		dd[i]+=1
print(dd)
print()
print()
print(OrderedDict(sorted(dd.items(),key=itemgetter(1),reverse=True)))
print('done')
