#!/usr/bin/python3
x=int(input('Enter an integer: '))
print('input is',x)
if x < 4:print('input must be > 4');exit()
start=2;end=int(x/2)
prime=True
for i in range(start,end+1):
	if x % i == 0:
		prime=False
		break
print(x,i,prime)
