#!/usr/bin/python3
import random
def getrand():
	n=random.randrange(97,123)
	return(n,chr(n))
class mkleaf():
	def __init__(self,num):
		self.num=getrand()
		self.char=chr(num)
		self.left=None
		self.right=None
class bstree():
	def __init__(self):
		self.head=None
		self.left=None
		self.right=None
	def add():
		newleaf=mkleaf()
		if self.head == None:self.head=newleaf;return()
		nextptr=self.head
		while nextptr.left != None:
			if newleaf.num < nextptr.num:
				nextptr=nextptr.left
				continue
			else:
				nextptr.left=newleaf
				return()
		while nextptr.right != None:
			if newleaf.num > nextptr.num
				nextptr=nextptr.right
				continue
			else:
				nextptr.right=newleaf
				return()
