#!/usr/bin/python3
def fib(l):
	end=len(l)-1
	start=len(l)-2
	l.append(l[start]+l[end])
	return(l)
l=[0,1]
for i in range(7):
	l=fib(l)
print(l)
