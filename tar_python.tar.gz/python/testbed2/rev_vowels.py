#!/usr/bin/python3
import sys
s=input('Input a string containing vowels: ')
print('The input string, length is',s,len(s))
vows='aeiouyAEIOUY'
print(vows)
s=list(s)
i=0;j=len(s)-1
while i < j:
	if s[i] not in vows:
		i+=1
		continue
	if s[j] not in vows:
		j-=1
		continue
	tmp=s[i]
	s[i]=s[j]
	s[j]=tmp
	i+=1;j-=1
srev=''.join(x for x in s)
print(srev)
print(s)
print('done')
