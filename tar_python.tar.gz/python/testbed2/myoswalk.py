#!/usr/bin/python3
import re,subprocess
def osw(lsaF,n):
	n+=1
	for l in re.split('\n',lsaF):
		print((n*' '),l)
		if l.rstrip('/') == '.' or l.rstrip('/') == '..':continue
		if l.endswith('/'):
			qq="ls -aF "+str(l.rstrip('/'))
			osw(subprocess.getoutput(qq),n)
	return()
osw(subprocess.getoutput('ls -aF'),1)
print(' ..done')
