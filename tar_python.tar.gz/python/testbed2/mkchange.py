#!/usr/bin/python3
from collections import OrderedDict
from operator import itemgetter
d={'twenties':2000.,'tens':1000.,'fives':500.,'ones':100.,'quarters':25.,'dimes':10.,'nickels':5.,'cents':1.}
od=OrderedDict(sorted(d.items(),key=itemgetter(1),reverse=True))
cd=od.fromkeys(od.keys(),0)
c=input('Enter cost of item: ')
p=input('Enter amt paying: ')
print('cost is $%5.2f'%float(c))
print('amt paying is $%5.2f'%float(p))
c=100.*float(c)
p=float(p)*100.
x=int(p-c)
for i in range(len(d)):
	if x <= 0.0:break
	if list(od.values())[i] > x:continue
	cd[list(od.keys())[i]]=int(x/list(od.values())[i])
	x-=cd[list(od.keys())[i]]*list(od.values())[i]
print(cd)
