#!/usr/bin/python3
def f(*args,**kwargs):
	print(args,kwargs)
	print(args[0],kwargs['a'])
f(1,2,3,a=10,b=20,c=30)
""" OUTPUT
(1, 2, 3) {'a': 10, 'b': 20, 'c': 30}
1 10
"""
