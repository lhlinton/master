#!/usr/bin/python3
import re,os,sys,string
import collections,subprocess
from functools import reduce

class TreeNode:
	def __init__(self,value):
		self.value=value
		self.left=None
		self.right=None

def InsertNode(Head,NewNode):
	ival=NewNode.value
	CurrPtr=Head
	if CurrPtr.left == None and ival < CurrPtr.value:
		CurrPtr.left=NewNode
		return
	elif CurrPtr.right == None and ival > CurrPtr.value:
		CurrPtr.right=NewNode
		return
	elif CurrPtr.left != None and ival < CurrPtr.value:
		InsertNode(CurrPtr.left,NewNode)
		return
	elif CurrPtr.right != None and ival > CurrPtr.value:
		InsertNode(CurrPtr.right,NewNode)
		return
	else:
		return
 
def PrintTree(CurrNode,Depth,ParentNode):
	indent=30-7*Depth
	if ParentNode == None:
		print(indent*" ",CurrNode.value,"dep=",Depth,"pv=","root")
	else:
		print(indent*" ",CurrNode.value,"dep=",Depth,"pv=",ParentNode.value)
	if CurrNode.left != None:
		PrintTree(CurrNode.left,Depth+1,CurrNode)
	if CurrNode.right != None:
		PrintTree(CurrNode.right,Depth+1,CurrNode)

def GetMin(Head):
	Depth=0
	if Head == None:
		print("GetMin: Head Ptr of tree is None...exiting")
		exit(1)
	CurrPtr=Head
	while CurrPtr.left != None:
		CurrPtr=CurrPtr.left
		Depth+=1
	print("Depth of min value =",Depth)
	return(CurrPtr.value)

InitVal=[5,2,4,6,3,8,1,10]
print(InitVal)
CurrNode=TreeNode(InitVal[0])
Head=CurrNode;
for i in range(1,8):
#for i in range(1,len(InitVal)):
	CurrNode=TreeNode(InitVal[i])
	InsertNode(Head,CurrNode)
Depth=0
PrintTree(Head,Depth,None)
print("The min value of the tree is ",GetMin(Head))
