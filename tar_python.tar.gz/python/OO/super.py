#!/usr/bin/python3
class X:
	def __init__(self,num):
		self.v=num
	def wtf(self):
		print('Xnum= ',self.v)
class XX(X):
	def __init__(self,num):
		self.v=num
class XXX(X):
	def __init__(self,num):
		self.v=num
	def wtf(self):
		print('XXXnum= ',self.v)
class XXXX(X):
	def __init__(self,num):
		self.v=num
	def wtf(self):
		super().wtf()
		print('XXXXnum= ',self.v)
x=X(3)
x.wtf()
print('-----')
xx=XX(33)
xx.wtf()
print('-----')
xxx=XXX(333)
xxx.wtf()
print('-----')
xxxx=XXXX(3333)
xxxx.wtf()
"""OUTPUT
Xnum=  3
-----
Xnum=  33
-----
XXXnum=  333
-----
Xnum=  3333
XXXXnum=  3333
"""
