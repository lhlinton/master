#!/usr/bin/python3
import os,sys,re,os,string
from functools import reduce
class X:
	def __init__(self,num):
		self.num=num
		self.__num=54321
		print('INIT:',self.num)
	def XX(self):
		print('XX:self.num',self.num)
		self.__num=13
		print('XX:self.__num',self.__num)
	def XXX(self):
		print('XX:self.num',self.num,self.__num)
		self.__num=1313
		print('XX:self.__num',self.__num)
	def XXXX(self):
		print('XX:self.num',self.__num)
q=X(24)
q.XX()
q.XXX()
q.XXXX()
""" OUTPUT
INIT: 24
XX:self.num 24
XX:self.__num 13
XX:self.num 24 13
XX:self.__num 1313
XX:self.num 1313
"""
