#!/usr/bin/python3
import re,os,sys,string
import collections,subprocess
from functools import reduce
sys.path.append('/home/lee/python/OO')
from Classes import TreeNode
from Funcs import Power

#class TreeNode:
#	def __init__(self,value):
#		self.value=None
#		self.left=None
#		self.right=None
NumNode=1

def InitTreeNode(PrevNode,PrevRow):
	global NumNode
	if PrevRow < NumTreeRows:
		NumNode+=1
		CurrNode=TreeNode(NumNode*ValueSpread)
		PrevNode.left=CurrNode
		InitTreeNode(CurrNode,PrevRow+1)
		NumNode+=1
		CurrNode=TreeNode(NumNode*ValueSpread)
		PrevNode.right=CurrNode
		InitTreeNode(CurrNode,PrevRow+1)
	elif PrevRow == NumTreeRows:
		PrevNode.left=None
		PrevNode.right=None
		return
	else:
		print("InitTreeNode: Error in binary tree creation")
		exit(1)
def PrintTree(Curr):
	print(Curr.value)
	if Curr.left != None: PrintTree(Curr.left)
	if Curr.right != None: PrintTree(Curr.right)
ValueSpread=10
if len(sys.argv) != 2:
	print("Usage: cmd has 1 arg, the no. of tree rows")
	exit(1)
NumTreeRows=int(sys.argv[1])
if NumTreeRows < 1:
	print("NumTreeRows must be > 0 ... exiting")
	exit(1)
NumTreeNodes=Power(2,NumTreeRows)-1
print("NumTreeRows= ",NumTreeRows)
print("NumTreeNodes = ",NumTreeNodes)
NumLeafNodes=Power(2,NumTreeRows-1)
print("NumLeafNodes= ",NumLeafNodes)
PrevRow=1
Head=TreeNode(NumNode*ValueSpread)
CurrNode=Head
InitTreeNode(CurrNode,PrevRow)
PrintTree(Head)
print("done")
