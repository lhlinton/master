def Power(Num,RaiseTo):
	isum=1
	for i in range(RaiseTo):
		isum *=Num
	return isum
