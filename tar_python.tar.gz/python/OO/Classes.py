class TreeNode:
	def __init__(self,value):
		self.value=value
		self.left=None
		self.right=None
class LLNode:
	def __init__(self,value):
		self.value=value
		self.right=None
