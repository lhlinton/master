#!/usr/bin/python3
import sys
import re
#sys.path.append('/home/lee/bjn')
#import class_lnklst
class ListNode:
	def __init__(self, data):
		self.data = data
		self.next = None
class List:
	def __init__(self):
		self.head=None
		self.tail=None
	def InsertNode(self,num):
		new_node=ListNode(num)
		if self.head is None and self.tail is None:
			self.head = new_node
			new_node.data = num
			return()
		node_ptr = self.head
		while True:
			print("nptr",node_ptr.data)
			if node_ptr.data == num:
				print("duplicate number ",num)
				exit()
			if node_ptr.data < num:
				prev_ptr = node_ptr
				if node_ptr.next is None:
					node_ptr.next = new_node
					return()
				node_ptr = node_ptr.next
				continue
			if node_ptr.data > num:
				if self.head == node_ptr:
					new_node.next = self.head
					self.head = new_node
					return()
				prev_ptr.next = new_node
				new_node.next = node_ptr
				return()
	def PrintNodes(self):
		if self.head is None:
			print("No List")
			return()
		nd_ptr = self.head
		while True:
			print(nd_ptr.data)
			if nd_ptr.next is None: break
			nd_ptr=nd_ptr.next
	def FindNode(self,num):
		if self.head is None:
			print("No List")
			return()
		nd_ptr = self.head
		while True:
			if num == nd_ptr.data: return nd_ptr
			if nd_ptr.next is None: break
			nd_ptr=nd_ptr.next
	def DelNode(self,num):
		if self.head is None:
			print("No List")
			return()
		nd_ptr = self.head
		prev_ptr = None
		while True:
			if num == nd_ptr.data:
				if prev_ptr == None:
					self.head = nd_ptr.next
					return()
				if nd_ptr.next == None:
					self.head = None
					return()
				prev_ptr.next = nd_ptr.next
				return()
			prev_ptr = nd_ptr
			nd_ptr = nd_ptr.next
NodeList=List()
NodeList.PrintNodes()
NodeList.InsertNode(1)
NodeList.PrintNodes()
NodeList.InsertNode(3)
NodeList.PrintNodes()
NodeList.InsertNode(2)
NodeList.PrintNodes()
NodeList.InsertNode(0)
NodeList.PrintNodes()
nd_ptr=NodeList.FindNode(2)
print("FindNode 2", nd_ptr.data)
NodeList.DelNode(2)
NodeList.PrintNodes()
print("DONE")
