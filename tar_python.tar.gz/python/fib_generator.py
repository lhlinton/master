#!/usr/bin/python3
def fib():
  a=0;b=1
  while True:
    a,b=b,a+b
    yield(a)
f=fib()
for i in range(10):
  print(next(f))

