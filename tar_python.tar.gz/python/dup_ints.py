#!/usr/bin/python3
from collections import defaultdict
l=[1,2,3,4,5,3,2,9,2]
d=defaultdict(int)
print(l)
for i in range(len(l)):
	d[l[i]]+=1
print(dict(d))
for i in d:
	if d[i]>1:print(d[i],end=' ')
print()
"""OUTPUT
[1, 2, 3, 4, 5, 3, 2, 9, 2]
{1: 1, 2: 3, 3: 2, 4: 1, 5: 1, 9: 1}
3 2
"""
