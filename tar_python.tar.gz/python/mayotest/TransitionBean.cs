﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    class TransitionBean
    {
        private String mTransitionId = null;

        private ResourceBean mResourceBean = null;
        private ReaderBean mReaderBean = null;

        private String mSourceAreaId = null;
        private String mSourceAreaName = null;

        private String mDestinationAreaId = null;
        private String mDestinationAreaName = null;

        private String mAlertType = null;
        private String mAlertMessageText = null;
        private UserBean mUserBean = new UserBean();
        private UserGroupBean mUserGroupBean = new UserGroupBean();
        private String mEventDetailId = null;
        //private String mMaxEventDetailId = null;

        private bool mSendAlert = false;

        public void setEventDetailId(String eventDetailId)
        {
            this.mEventDetailId = eventDetailId;
        }

        public String getEventDetailId()
        {
            return this.mEventDetailId;
        }


       /* public void setMaxEventDetailId(String maxEventDetailId)
        {
            this.mMaxEventDetailId = maxEventDetailId;
        }

        public String getMaxEventDetailId()
        {
            return this.mMaxEventDetailId;
        }*/


        public String getAlertMessageText()
        {
            return mAlertMessageText;
        }

        public void setAlertMessageText(String alertMessageText)
        {
            this.mAlertMessageText = alertMessageText;
        }

        public String getAlertType()
        {
            return mAlertType;
        }

        public void setAlertType(String alertType)
        {
            this.mAlertType = alertType;
        }

        public String getDestinationAreaId()
        {
            return mDestinationAreaId;
        }

        public void setDestinationAreaId(String destinationAreaId)
        {
            this.mDestinationAreaId = destinationAreaId;
        }

        public String getDestinationAreaName()
        {
            return mDestinationAreaName;
        }

        public void setDestinationAreaName(String destinationAreaName)
        {
            this.mDestinationAreaName = destinationAreaName;
        }


        public ReaderBean getReaderBean()
        {
            return mReaderBean;
        }

        public void setReaderBean(ReaderBean readerBean)
        {
            this.mReaderBean = readerBean;
        }

        public ResourceBean getResourceBean()
        {
            return mResourceBean;
        }

        public void setResourceBean(ResourceBean resourceBean)
        {
            this.mResourceBean = resourceBean;
        }

        public bool getSendAlert()
        {
            return mSendAlert;
        }

        public void setSendAlert(bool sendAlert)
        {
            this.mSendAlert = sendAlert;
        }

        public String getSourceAreaId()
        {
            return mSourceAreaId;
        }

        public void setSourceAreaId(String sourceAreaId)
        {
            this.mSourceAreaId = sourceAreaId;
        }
        public String getSourceAreaName()
        {
            return mSourceAreaName;
        }

        public void setSourceAreaName(String sourceAreaName)
        {
            this.mSourceAreaName = sourceAreaName;
        }


        public String getTransitionId()
        {
            return mTransitionId;
        }

        public void setTransitionId(String transitionId)
        {
            this.mTransitionId = transitionId;
        }


        public UserBean getUserBean()
        {
            return this.mUserBean;
        }
        public UserGroupBean getUserGroupBean()
        {
            return this.mUserGroupBean;
        }

    }
}
