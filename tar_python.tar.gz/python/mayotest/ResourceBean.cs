﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    class ResourceBean
    {
        private String mId = null;
        private String mName = null;
        private String mResourceTypeId = null;
        private String mTagId = null;
        private String mPrevReaderId = "-1";

        public String getPrevReaderId()
        {
            return mPrevReaderId;
        }

        public void setPrevReaderId(String prevReaderId)
        {
            this.mPrevReaderId = prevReaderId;
        }

        public String getResourceTypeId()
        {
            return mResourceTypeId;
        }

        public void setResourceTypeId(String resourceTypeId)
        {
            this.mResourceTypeId = resourceTypeId;
        }

        public String getId()
        {
            return mId;
        }

        public void setId(String id)
        {
            this.mId = id;
        }

        public String getName()
        {
            return mName;
        }

        public void setName(String name)
        {
            this.mName = name;
        }

        public String getTagId()
        {
            return mTagId;
        }

        public void setTagId(String tagId)
        {
            this.mTagId = tagId;
        }

    }
}
