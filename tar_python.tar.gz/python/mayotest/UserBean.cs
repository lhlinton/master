﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    class UserBean
    {
        private String mId = null;
        private String mName = null;
        private String mEmailId = null;


        public String getEmailId()
        {
            return mEmailId;
        }

        public void setEmailId(String emailId)
        {
            this.mEmailId = emailId;
        }


        public String getId()
        {
            return mId;
        }

        public void setId(String id)
        {
            this.mId = id;
        }

        public String getName()
        {
            return mName;
        }

        public void setName(String name)
        {
            this.mName = name;
        }
    }
}
