﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    class CorrelationBean
    {
        private String mId;
        private String mTransitionId1;
        private String mTransitionId2;
        private String mDuration;
        private String mDescription;
        private String mAlertType = null;
        private String mAlertMessageText = null;
        private UserBean mUserBean = new UserBean();
        private UserGroupBean mUserGroupBean = new UserGroupBean();

        public String getId()
        {
            return mId;
        }

        public void setId(String id)
        {
            this.mId = id;
        }

        public String getDuration()
        {
            return mDuration;
        }

        public void setDuration(String duration)
        {
            this.mDuration = duration;
        }

        public String getDescription()
        {
            return mDescription;
        }

        public void setDescription(String description)
        {
            this.mDescription = description;
        }

        public String getTransitionId1()
        {
            return mTransitionId1;
        }

        public void setTransitionId1(String transitionId1)
        {
            this.mTransitionId1 = transitionId1;
        }
        public String getTransitionId2()
        {
            return mTransitionId2;
        }

        public void setTransitionId2(String transitionId2)
        {
            this.mTransitionId2 = transitionId2;
        }


        public String getAlertMessageText()
        {
            return mAlertMessageText;
        }

        public void setAlertMessageText(String alertMessageText)
        {
            this.mAlertMessageText = alertMessageText;
        }

        public String getAlertType()
        {
            return mAlertType;
        }

        public void setAlertType(String alertType)
        {
            this.mAlertType = alertType;
        }

        public UserBean getUserBean()
        {
            return this.mUserBean;
        }
        public UserGroupBean getUserGroupBean()
        {
            return this.mUserGroupBean;
        }

    }
}
