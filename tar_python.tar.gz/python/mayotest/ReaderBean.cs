﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    class ReaderBean
    {
        private String mId = null;
        private String mName = null;
        private String mFunctionalAreaId = null;
        private String mSecurityAreaId = null;
        private String mFunctionalAreaName = null;
        private String mSecurityAreaName = null;
        private String mSiteId = "-1";

        public String getSiteId()
        {
            return mSiteId;
        }

        public void setSiteId(String siteId)
        {
            this.mSiteId = siteId;
        }

        public String getSecurityAreaId()
        {
            return mSecurityAreaId;
        }

        public void setSecurityAreaId(String securityAreaId)
        {
            this.mSecurityAreaId = securityAreaId;
        }

        public String getSecurityAreaName()
        {
            return mSecurityAreaName;
        }

        public void setSecurityAreaName(String securityAreaName)
        {
            this.mSecurityAreaName = securityAreaName;
        }

        public String getId()
        {
            return mId;
        }

        public void setId(String id)
        {
            this.mId = id;
        }

        public String getName()
        {
            return mName;
        }

        public void setName(String name)
        {
            this.mName = name;
        }

        public String getFunctionalAreaId()
        {
            return mFunctionalAreaId;
        }

        public void setFunctionalAreaId(String functionalAreaId)
        {
            this.mFunctionalAreaId = functionalAreaId;
        }

        public String getFunctionalAreaName()
        {
            return mFunctionalAreaName;
        }

        public void setFunctionalAreaName(String functionalAreaName)
        {
            this.mFunctionalAreaName = functionalAreaName;
        }

    }
}
