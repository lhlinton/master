﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{

    class AlertBean
    {
        public enum ELEMENT_TYPE
        {
            TRANSITION,
            CORRELATION,
            UNKNOWN_TAG,
            UNKNOWN_READER
        };
        private ELEMENT_TYPE mElementType = ELEMENT_TYPE.TRANSITION;
        private TransitionBean mTransitionBean = null;
        private CorrelationBean mCorrelationBean = null;
        private UnknownTagBean mUnknownTagBean = null;

        public void setElementType(ELEMENT_TYPE elementType)
        {
            this.mElementType = elementType;
        }

        public ELEMENT_TYPE getElementType()
        {
            return this.mElementType;
        }

        public void setTransitionBean(TransitionBean transitionBean)
        {
            this.mTransitionBean = transitionBean;
        }

        public TransitionBean getTransitionBean()
        {
            return this.mTransitionBean;
        }

        public void setCorrelationBean(CorrelationBean correlationBean)
        {
            this.mCorrelationBean = correlationBean;
        }

        public CorrelationBean getCorrelationBean()
        {
            return mCorrelationBean;
        }

        public void setUnknownTagBean(UnknownTagBean unknownTagBean)
        {
            this.mUnknownTagBean = unknownTagBean;
        }

        public UnknownTagBean getUnknownTagBean()
        {
            return mUnknownTagBean;
        }
    }
}
