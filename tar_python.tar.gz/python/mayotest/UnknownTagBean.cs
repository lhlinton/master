﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    class UnknownTagBean
    {
        private String mEmail = null;
        private String mAlertMessage = null;

        public void setEmail(String email)
        {
            this.mEmail = email;
        }

        public String getEmail()
        {
            return this.mEmail;
        }

        public void setAlertMessage(String alertMessage)
        {
            this.mAlertMessage = alertMessage;
        }

        public String getAlertMessage()
        {
            return this.mAlertMessage;
        }
    }
}
