﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{
    enum EVENT_TYPE
    {
        GLIMPSE,
        OBSERVED,
        LOST
    };

    class EventBean
    {

        private EVENT_TYPE mEventType;
        private DateTime mEventTime = DateTime.Now;
        private LinkedList<TransitionBean> mTransitionBeans = new LinkedList<TransitionBean>();
        private LinkedList<CorrelationBean> mCorrelationBeans = new LinkedList<CorrelationBean>();
        private ResourceBean mResourceBean = new ResourceBean();
        private ReaderBean mReaderBean = new ReaderBean();

        public ReaderBean getReaderBean()
        {
            return mReaderBean;
        }



        public ResourceBean getResourceBean()
        {
            return mResourceBean;
        }

        public LinkedList<CorrelationBean> getCorrelationBeans()
        {
            return mCorrelationBeans;
        }

        public LinkedList<TransitionBean> getTransitionBeans()
        {
            return mTransitionBeans;
        }


        public EVENT_TYPE getEventType()
        {
            return mEventType;
        }
        public void setEventType(EVENT_TYPE eventType)
        {
            this.mEventType = eventType;
        }


        public DateTime getEventTime()
        {
            return mEventTime;
        }
        public void setEventTime(DateTime eventTime)
        {
            this.mEventTime = eventTime;
        }

    }
}
