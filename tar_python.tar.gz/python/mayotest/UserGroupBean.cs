﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Argusoft.EATS.ReaderApp.DataBean
{

    class UserGroupBean
    {

        private String mId = null;
        private String mName = null;
        private LinkedList<UserBean> mUsers = new LinkedList<UserBean>();

        public String getId()
        {
            return mId;
        }

        public void setId(String id)
        {
            this.mId = id;
        }

        public String getName()
        {
            return mName;
        }

        public void setName(String name)
        {
            this.mName = name;
        }

        public LinkedList<UserBean> getUsers()
        {
            return mUsers;
        }

        public void setUsers(LinkedList<UserBean> users)
        {
            this.mUsers = users;
        }
    }
}
