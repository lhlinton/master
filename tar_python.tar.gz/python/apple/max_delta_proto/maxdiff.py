#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
l1=[1.1,2.2,3.3,4.4,5.5]
l2=[11.1,22.2,33.3,44.4,55.5]
l3=list(zip(l2,l1))
l4=[]
for x,y in l3:
	l4.append(abs(x-y))
for i in range(len(l4)):
	print("%.2f" % l4[i]," ",end="")
print(" ")
mxdiff=reduce(lambda x,y: x if x>y else y,l4)
print("mxdiff = ",mxdiff)
mxdiff=max(l4)
print("mxdiff = ",mxdiff)
