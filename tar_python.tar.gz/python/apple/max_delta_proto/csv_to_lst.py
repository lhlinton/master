#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
with open('base.csv','r') as base:
	base_line=base.read().splitlines()
b=base_line[0].strip()
base_list=re.split(",",b)
flt_base_list=[]
for i in range(len(base_list)):
	flt_base_list.append(float(base_list[i]))
print(flt_base_list)
fbl=list(map(lambda x: float(x),base_list))
print(fbl)
fbl=list(map(float,base_list))
print(fbl)
