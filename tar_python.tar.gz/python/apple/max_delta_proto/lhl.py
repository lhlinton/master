#!/usr/bin/python3
# Not all imports needed

import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce

def max_diff(list1,list2):
	tuple_list=list(zip(list1,list2))
	diff_list=[]
	for x,y in tuple_list:
		diff_list.append(abs(x-y))
	return max(diff_list) # reduce(lambda x,y: x if x>y else y,diff_list)

def csv_to_flt_lst(filename):
	with open(filename,'r') as fn:
		lines=fn.read().splitlines()
	line=lines[0].strip()
	csv_tokens=re.split(",",line)
	flt_lst=list(map(float,csv_tokens))
	return flt_lst

NumArgs=3
Usage="Usage: <cmd_name> <path/filename> <path/filename>"
if len(sys.argv) != NumArgs : 
	print(Usage)
	exit(1)
basefile=sys.argv[1]
currfile=sys.argv[2]
baselist=csv_to_flt_lst(basefile)
currlist=csv_to_flt_lst(currfile)
max_delta=max_diff(currlist,baselist)
print("max delta = ",max_delta)
