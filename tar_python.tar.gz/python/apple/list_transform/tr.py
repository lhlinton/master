#!/usr/bin/python3
import csv, re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
#Usage="Usage: "
#if len(sys.argv) != 2 : 
#	print(Usage)
#	exit(1)
#arg1=sys.argv[1]

with open('csv1','r') as csv1:
	csvlist1=csv1.read().splitlines()
for i in range(len(csvlist1)):
	csvlist1[i]=csvlist1[i].replace('"','')
	csvlist1[i]=csvlist1[i].split(',')
print("FIRST 2 LINES OF MODEL TRANSFORMED FILE:")
print(csvlist1[0])
print(csvlist1[1])
print('\n')

with open('csv2','r') as csv2:
	csvlist2=csv2.read().splitlines()
print("LINES OF FILE TO TRANSFORM:")
for i in range(len(csvlist2)):
	csvlist2[i]=csvlist2[i].replace('"','')
	csvlist2[i]=csvlist2[i].split(',')
	print(csvlist2[i])
print('\n')

with open('dict_transform','r') as dt:
	trdict=eval(dt.read())
print("TRANSFORMATION DICTIONARY FOR LOAD METRICS")
print(trdict)
maplist=[]
print("TRANSFORMATION INDEX SOURCE MAPPINGS")
for k,v in trdict.items():
	print(v,csvlist2[0].index(v),end=' ')
	maplist.append(csvlist2[0].index(v))
print('\n',maplist)

headers=[]
for k,v in trdict.items():
	headers.append(k)
print("TRANFORMATION HEADERS")
print('headers:',headers)
with open('transformed_file','w') as trf:
	headers=','.join('"' + i + '"' for i in headers)
	trf.write(headers+'\n')

	print("TRANSFORMATION TARGET MAPPING")
	for row in csvlist2[1:]:
		newrow=[]
		mapindex=0
		for k,v in trdict.items():
			newrow.append(row[maplist[mapindex]])
			mapindex+=1
		print('newrow:',newrow)
		newrow=','.join('"' + i + '"' for i in newrow)
		trf.write(newrow+'\n')
