#!/usr/local/bin/python3
# Not all imports needed
#dict(zip(x,y))

import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
#from enum import Enum
def enum(*args):
	enums = dict(zip(args, range(1,len(args)+1)))
	return type('Enum', (), enums)

LoadMetrics=enum(	"Concurrency",
									"Target Duration (seconds)")
"""
									"Duration (seconds)"])
									"Start",
									"End",
									"80% Latency (ms)",
									"90% Latency (ms)",
									"95% Latency (ms)",
									"98% Latency (ms)",
									"99% Latency (ms)",
									"99.5% Latency (ms)",
									"99.8% Latency (ms)",
									"99.9% Latency (ms)",
									"Max Latency (ms)",
									"Mean Latency (ms)",
									"Median Latency (ms)",
									"Minimum Latency (ms)",
									"Latency Standard Deviation",
									"Latency Variance","Failed (qps)",
									"Successful (qps)",
									"Timedout (qps)",
									"Failure Rate",
									"Success Rate",
									"Timeout Rate",
									"Failed Requests",
									"Successful Requests",
									"Timedout Requests",
									"Total Requests",
									"80% Response Size (bytes)",
									"90% Response Size (bytes)",
									"95% Response Size (bytes)",
									"98% Response Size (bytes)",
									"99% Response Size (bytes)",
									"99.5% Response Size (bytes)",
									"99.8% Response Size (bytes)",
									"99.9% Response Size (bytes)",
									"Maximum Response Size (bytes)",
									"Mean Response Size (bytes)",
									"Median Response Size (bytes)",
									"Minimum Response Size (bytes)",
									"Response Size Standard Deviation",
									"Response Size Variance"])
"""
print(LoadMetrics.Concurrency)
print(LoadMetrics.'Target Duration (seconds)')
print('\tdone')
