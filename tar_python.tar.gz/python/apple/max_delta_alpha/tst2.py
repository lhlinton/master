#!/usr/bin/python3
# Not all imports needed
#dict(zip(x,y))
#
# 2 dicts: 1) LoadMetricIndex, 2) LoadMetricLoad
#			where each dict uses the testname as the key and
#			1) the index in row/line 0 is the value
#			2) the load/concurrency or first vnumber in the 
#					succeeding rows/lines is the value
#
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from lib_mapsperf import *
#from enum import Enum
#def enum(*args):
#	enums = dict(zip(args, range(1,len(args)+1)))
#	return type('Enum', (), enums)

print("***start\n")
with open('basefile','r') as basefile:
	lines=basefile.read().splitlines()
print(lines[0])
LineTokens=re.split(",",lines[0])
LineTokenIndex=range(len(LineTokens))
LoadMetricIndex=dict(zip(LineTokens,LineTokenIndex))
print(LineTokens[0],LineTokens[1],LineTokens[2])
for k,v in LoadMetricIndex.items():
	print(k,v)
kk="Successful (qps)"
for k,v in LoadMetricIndex.items():
#	if k == "Successful (qps)":
	if k.replace('"','') == kk:
		print('EUREKA',k," index = ",v)
	if v == 20:
#		print('*',k,'*',kk,'*')
		print('*'+k+'*'+str(kk)+'*')
		exit(0)
print('\n***done')
