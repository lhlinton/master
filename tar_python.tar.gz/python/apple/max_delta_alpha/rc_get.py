#!/usr/bin/python
import sys
import requests
from collections import defaultdict

for arg in sys.argv[1:]:
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Token 55ee01b7-30e6-4d19-a5ec-d01503e3f762'
    }
    output = ""
    #import pdb; pdb.set_trace()
    r = requests.get('https://rollercoaster.geo.apple.com/matterhorn/v1/results?runId={}&per_page=0'.format(arg), headers=headers)
    run = r.json()
    result_dict = defaultdict(list)
    for run_line in run['results']:
        for k, v in run_line.iteritems():
            if not isinstance(v, dict):
                result_dict[k].append(v)
    headers = result_dict.keys()
    index = 0    
    output += ",".join(headers)
    output += "\n"
    while 1:
        try:
            output += ",".join([str(result_dict[h][index])
                                for h in headers])
            output += "\n"            
            index = index + 1
        except IndexError:
            break
    out_file = open("{}.csv".format(arg), "w")
    out_file.write(output)
    out_file.close()

        
        
