import csv
def max_diff(list1,list2):
	tuple_list=list(zip(list1,list2))
	diff_list=[]
	for x,y in tuple_list:
		diff_list.append(abs(x-y))
	return max(diff_list) # reduce(lambda x,y: x if x>y else y,diff_list)

def csv_to_flt_lst(filename,LoadMetric):
	TestFile=csv.DictReader(open(filename,'r'))
	TestList=[]
	for row in TestFile:
		for k,v in row.items():
			if k == LoadMetric:
				TestList.append(float(v))
				break
	return TestList
