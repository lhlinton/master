#!/usr/bin/python3
import csv
from lib_mapsperf import *

BaseFile = csv.DictReader(open("basefile.csv",'r'))
CurrFile = csv.DictReader(open("currfile.csv",'r'))
BaseList=[]
CurrList=[]
LoadMetric='Successful (qps)'
for row in BaseFile:
	for k,v in row.items():
		if k == LoadMetric:
			BaseList.append(float(v))
			break
print(BaseList,"\n")
for row in CurrFile:
	for k,v in row.items():
		if k == LoadMetric:
			CurrList.append(float(v))
			break
print(CurrList,"\n")
max_delta=max_diff(BaseList,CurrList)
print("max delta = %.2f" % max_delta)
