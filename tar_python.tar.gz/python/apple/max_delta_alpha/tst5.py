#!/usr/bin/python3
from lib_mapsperf import *

LoadMetric='Successful (qps)'
BaseList=csv_to_flt_lst('basefile.csv',LoadMetric)
print(BaseList,"\n")
CurrList=csv_to_flt_lst('currfile.csv',LoadMetric)
print(CurrList,"\n")
max_delta=max_diff(BaseList,CurrList)
print("max delta = %.2f" % max_delta)
