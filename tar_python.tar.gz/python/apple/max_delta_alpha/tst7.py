#!/usr/bin/python3
import re
from lib_mapsperf import *

LoadMetricStartIndex=5
with open('basefile.csv','r') as basefile:
	TestLine=basefile.readline().strip()
TestLine=TestLine.replace('"','')
TestList=re.split(',',TestLine)
TestList=[TestList[index] for index in range(LoadMetricStartIndex,len(TestList))]

ThreshList=[]
with open('maps_perf_tests_thresholds.txt','r') as ThreshFile:
	ThreshLines=ThreshFile.read().splitlines()
for line in range(1,len(ThreshLines)):
	LineList=re.split('\s+',ThreshLines[line])
	ThreshList.append(LineList[len(LineList)-1])
print(ThreshList)

for i in range(len(TestList)):
	LoadMetric=TestList[i]
	BaseList=csv_to_flt_lst('basefile.csv',LoadMetric)
	print(BaseList,"\n")
	CurrList=csv_to_flt_lst('currfile.csv',LoadMetric)
	print(CurrList,"\n")
	max_delta=max_diff(BaseList,CurrList)
	print("max delta = %.2f" % max_delta)
