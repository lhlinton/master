def ListToDict(l):
	d={}
	for k in range(0,len(l),2):
		d.update({l[k]:l[k+1]})
	print(l)
	return d

def DictToList(d):
	l=[]
	for k,v in d.items():
		l.extend([k,v])
	return l

def max_diff(list1,list2):
	tuple_list=list(zip(list1,list2))
	diff_list=[]
	for x,y in tuple_list:
		diff_list.append(abs(x-y))
	return max(diff_list) # reduce(lambda x,y: x if x>y else y,diff_list)

def csv_to_flt_lst(filename):
	with open(filename,'r') as fn:
		lines=fn.read().splitlines()
	line=lines[0].strip()
	csv_tokens=re.split(",",line)
	flt_lst=list(map(float,csv_tokens))
	return flt_lst
