#!/usr/bin/python3
import re
from lib_mapsperf import *

LoadMetricStartIndex=5
with open('basefile.csv','r') as basefile:
	TestLine=basefile.readline().strip()
TestLine=TestLine.replace('"','')
TestList=re.split(',',TestLine)
TestList=[TestList[index] for index in range(LoadMetricStartIndex,len(TestList))]

ThreshList=[]
with open('maps_perf_tests_thresholds.txt','r') as ThreshFile:
	ThreshLines=ThreshFile.read().splitlines()
for line in range(1,len(ThreshLines)):
	LineList=re.split('\s+',ThreshLines[line])
	ThreshList.append(LineList[len(LineList)-1])
print(ThreshList)
print("------------------------------------------------------------------------------")

for i in range(len(TestList)):
	LoadMetric=TestList[i]
	BaseList=csv_to_flt_lst('basefile.csv',LoadMetric)
	print(BaseList,"\n")
	CurrList=csv_to_flt_lst('currfile.csv',LoadMetric)
	print(CurrList,"\n")
	max_delta_percent=max_diff_percent(BaseList,CurrList)
	print("max delta percent = %.1f" % (max_delta_percent*100.))
	print("Threshold = ",ThreshList[i],"%")
	print("LoadMetric = ",TestList[i])
	print("LoadMetricIndex = ",i)
	if max_delta_percent < abs(float(ThreshList[i])/100.):
		print("PASS","\n-------------------------------------------------------------------")
	else:
		print("FAIL","\n-------------------------------------------------------------------")
