#!/usr/bin/python3
import re
from lib_mapsperf import *

LoadMetricStartIndex=5
with open('basefile.csv','r') as basefile:
	TestLine=basefile.readline().strip()
TestLine=TestLine.replace('"','')
TestList=re.split(',',TestLine)
TestList=[TestList[index] for index in range(LoadMetricStartIndex,len(TestList))]
for i in range(len(TestList)):
	LoadMetric=TestList[i]
	BaseList=csv_to_flt_lst('basefile.csv',LoadMetric)
	print(BaseList,"\n")
	CurrList=csv_to_flt_lst('currfile.csv',LoadMetric)
	print(CurrList,"\n")
	max_delta=max_diff(BaseList,CurrList)
	print("max delta = %.2f" % max_delta)
print("test len = ",len(TestList))
