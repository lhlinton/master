#!/usr/bin/python3
import os,sys,re
import subprocess
def oswalk(f):
	lines=re.split('\n',f)
	for l in lines:
		fn=re.split('\s+',l)
		print(fn[0])
		if fn[0].endswith('/'):oswalk(fn[0].rstrip('/'))
f=subprocess.getoutput('ls -aF /home/lee/python/OO')
oswalk(f)
print(' done')
