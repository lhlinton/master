#!/usr/bin/python3
import re,os,sys,string
s="abc45def45vvv12"
ls=list(s)
aa=[]
n=[]
x=[]
for ind in s:
  if ind.isnumeric():
        n.append(ind)
        continue
  else:
    number=''.join('' + k for k in n)
    nn=int(number)
    x.append(nn)
    n=[]
q=max(x)
print("max no is ",q)

i=0
for j in range(len(x)):
    if q == x[j]:
        i+=1
print("num of maxes = ",i)

