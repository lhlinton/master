#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from collections import OrderedDict,defaultdict
from operator import itemgetter
dd=defaultdict(int)
with open('word_count_input_file.txt','r') as f:
	lines=f.read().splitlines()
for l in lines:
	tokens=re.split('\s+',l.strip())
	for t in tokens:
		dd[t]+=1
ddsort=OrderedDict(sorted(dd.items(),key=itemgetter(1),reverse=True))
for k,v in ddsort.items():
	print(k,v)
