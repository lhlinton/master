#!/usr/bin/python3
# Hello world python program
print ("Hello World!")
import os
#os.system("man date")
f = os.popen('man date')
now = f.read()
print ("Today is ", now)
#print ("Bye now")
