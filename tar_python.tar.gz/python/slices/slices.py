#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
#Usage="Usage: "
#if len(sys.argv) != 2 : 
#	print(Usage)
#	exit(1)
#arg1=sys.argv[1]
l=['1','2','3','4','5']
print(l)  # ['1', '2', '3', '4', '5']
print(l[1:4]) # ['2', '3', '4']
print(l[1:])  # ['2', '3', '4', '5']
print(l[::2]) # ['1', '3', '5']
print(l[:-1]) # ['1', '2', '3', '4']
print(l[::-1]) # ['5', '4', '3', '2', '1']
