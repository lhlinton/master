#!/usr/bin/python3
import re,os,sys
s="abcde33ghij22kkk"
print(s)
ss=list(s)
print(ss)
aa=[]
cond='alpha'
for ind in ss:
	precond=cond
	if ind.isdigit(): 
		cond='num'
		if precond == cond:
			aa[len(aa)-1]+=ind
		else:
			aa.append(ind)
	else:
		cond='alpha'
print("len of aa = ",len(aa))
print(aa)
