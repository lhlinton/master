#!/usr/bin/python3
BUCKETS=31
hsh=[[] for i in range(BUCKETS)]
while True:
	n=int(input('Enter no. of ints to hash > '))
	print('no. of ints to hash= ',n)
	for i in range(n):
		buck=i % BUCKETS
		hsh[buck].append(i)
	for i in range(BUCKETS):
		print(i,' ',len(hsh[i]),' ',end='')
		for j in range(len(hsh[i])):print(hsh[i][j],end=' ')
		print()
