#!/usr/bin/python3
from collections import defaultdict
amtlst=[500,100,25,10,5,1]
denoms=['Fives','Ones','Quarters','Dimes','Nickels','Cents']
nconv=len(amtlst)
(price,amt)=input('Enter the price and amt paid > ').split()
price=int(float(price)*100)
amt=int(float(amt)*100)
print(price,amt)
diff=amt-price
print('diff= ',diff)
chlst=[]
print(amtlst)
print('--------------')
for i in range(nconv):
	nval=int(diff/amtlst[i])
	chlst.append(nval)
	diff-=nval*amtlst[i]
print(chlst)
for i in range(len(chlst)):
	if chlst[i] == 0:continue
	print(chlst[i],denoms[i])
