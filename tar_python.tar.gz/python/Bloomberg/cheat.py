#!/usr/bin/python3
import re
patip=re.compile('ip')
pataddr=re.compile('\d+(\.\d+){3}')
with open('cpout_lhl','r') as f:
	lines=f.read().splitlines()
for line in lines:
	tokens=re.split('\s+',line)
	if re.match(patip,tokens[0]):
		if re.match(pataddr,tokens[2]):
			print(tokens[2])
			break
