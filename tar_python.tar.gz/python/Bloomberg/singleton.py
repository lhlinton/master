#!/usr/bin/python3
class LogIs:
	__isopen=False
	def __init__(self):
		if LogIs.__isopen is False:
			LogIs.__isopen=True
			print('opening logfile')
		else:
			print('Log Is already open ')
class Log(LogIs):
	def write(self):
		print('writing msg')
w1=Log()
w1.write()
w1.write()
w2=Log()
w2.write()
w2.write()
"""OUTPUT
opening logfile
writing msg
writing msg
Log Is already open 
writing msg
writing msg
"""
