#!/usr/bin/python3
import re
s='xabvfabhabzna'
s='xabcvqabcgggabc'
print('string is ',s)
l=len(s)
print('len of s = ',l)
slist=[]
maxlen=1
#
#Min pattern is 2 char substring that repeats at least once
#
max_match_len=int(l/2)

for i in range(2,max_match_len+1):
	for j in range(len(s)-1):
		s0=s[j]
		for k in range(j+1,j+i):
			if k > l-1:break
			print('DBG: ',i,j,k,l)
			s0+=s[k]
		print('DBG2: ',s0)
		x=re.findall(s0,s)
		if len(x) > 1:
			print('pattern exists > ',x)
			z=len(x[0])
			if z > maxlen:
				maxlen=z
				maxpat=x[0]
			slist.extend([x])
print("FINAL RESULTS:")
print(slist)
print('MAXSUBSTR, MAXLEN = ',maxpat,maxlen)
