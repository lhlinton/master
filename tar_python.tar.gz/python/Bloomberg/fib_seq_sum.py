#!/usr/bin/python3
def FibSum(n):
	if n==1:return 0
	if n=2:return 1
	sum=1
	prev=1
	l=[]
	l.append(
	for i in range(3,n+1):
		
