#!/usr/bin/python3
def factorial(n):
	if n > 1:
		return(n * factorial(n-1))
	else:
		return(1)
input_str=input('Enter an anagram str > ')
input_lst=list(input_str)
print('input str is ',input_str)
input_str_len=len(input_str)
anagram_perms=factorial(input_str_len)
print('The no. of anagram permutations is ',anagram_perms)
anagrams=[[] for i in range(anagram_perms)]
nlsts=int(anagram_perms/input_str_len)
permlen=input_str_len-1
# 
# Set up first list item 
# 
for i in range(nlsts):
	anagrams[i].append(input_str[0])
print(anagrams)
print()
#
offset=0
stride=0
for i in range(nlsts):
	ind=((i + offset) % permlen) + 1
	anagrams[i].append(input_str[ind])
print(anagrams)
print()
# 
offset+=1
for i in range(nlsts):
	ind=((i + offset) % permlen) + 1
	anagrams[i].append(input_str[ind])
print(anagrams)
print()
	
