#!/usr/bin/python3
import re
def loop_method(s,m):
	lqq=[]
	for i in range(0,len(s),m):
		qq=''
		for j in range(m):
			qq+=s[i+j]
		lqq.append(qq)
	return(lqq)
#
def re_method(s,m):
	pat=''
	for i in range(m):pat+='.'
	chunkpat=re.compile(pat)
	return(re.findall(chunkpat,s))
#
s,m=input('Enter a sentence enclosed in single or double quotes and chunk size separated by a comma > ').split(',')
s=s.strip("'")
s=s.strip('"')
m=int(m)
print('sentence is ',s)
print('The chunk size is ',m)
#
print('The sentence might be padded with blanks to make the length an even multiple of the chunk size')
pad=len(s) % m
if pad != 0:
	for i in range(m-pad):
		s+=' '
#
print('LOOP METHOD: ',loop_method(s,m))
print('RE METHOD: ',re_method(s,m))
""" SAMPLE RUN WITH OUTPUT
Enter a sentence and chunk size separated by a comma > 'how are you',4
sentence is  how are you
The chunk size is  4
The sentence might be padded with blanks to make the length an even multiple of the chunk size
LOOP METHOD:  ['how ', 'are ', 'you ']
RE METHOD:  ['how ', 'are ', 'you ']
"""
