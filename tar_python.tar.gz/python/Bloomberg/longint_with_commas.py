#!/usr/bin/python3
def Insert_Commas(n):
	nlen=len(n)
	l=list(n)
	cnt=0
	for i in range(nlen-1,-1,-1):
		cnt+=1
		if cnt % 3 == 0 and i != 0:l.insert(i,',')
	s=''.join(i for i in l)
	print('res= ',s)
while True:
	n=input('Enter a large integer without commas, e.g. 10000 > ')
	print('input is ',n)
	Insert_Commas(n)
"""OUTPUT
Enter a large integer without commas, e.g. 10000 > 100000
input is  100000
res=  100,000
"""
