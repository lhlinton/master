#!/usr/bin/python3
class BinTreeNode:
	def __init__(self,val):
		self.num=val
		self.left=None
		self.right=None
class BinTree:
	def __init__(self):
		self.head=None
	def add(self,num):
		newptr=BinTreeNode(num)
		if self.head == None:
			self.head=newptr
			return()
		else:
			prevptr=self.head
			while True:
				if newptr.num < prevptr.num:
					if prevptr.left == None:
						prevptr.left=newptr
						break
					else:
						prevptr=prevptr.left
						continue
				else:
					if prevptr.right == None:
						prevptr.right=newptr
						break
					else:
						prevptr=prevptr.right
						continue
	def pr(self):
		self.pr_helper(self.head)
		print('-------')
	def pr_helper(self,prevptr):
		if prevptr.left is not None:
			self.pr_helper(prevptr.left) 
		print(prevptr.num)
		if prevptr.right is not None:
			self.pr_helper(prevptr.right) 
		return()
	def GetMin(self):
		ptr=self.head
		while ptr.left is not None:
			ptr=ptr.left
		print('min is ',ptr.num)
x=BinTree()
y=BinTree()
x.add(9)
y.add(99)
x.pr()
x.add(2)
y.add(22)
x.pr()
x.add(1)
y.add(11)
x.pr()
x.add(17)
y.add(117)
x.pr()
x.add(13)
y.add(113)
x.pr()
x.add(3)
y.add(33)
x.pr()
y.pr()
x.GetMin()
y.GetMin()
"""OUTPUT
9
-------
2
9
-------
1
2
9
-------
1
2
9
17
-------
1
2
9
13
17
-------
1
2
3
9
13
17
-------
11
22
33
99
113
117
-------
min is  1
min is  11
"""
