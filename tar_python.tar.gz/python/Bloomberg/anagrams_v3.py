#!/usr/bin/python3
from copy import deepcopy
class node:
	def __init__(self,ch,n):
		self.char=ch
		self.lst=[None for i in range(n)] 
	def pr(self,root):
		self.ptr=root
		print(self.ptr.char)
		print('dbg1')
		print('dbg11 ',len(self.ptr.lst))
		if not self.ptr.lst:
			print('dbg2')
			print(self.ptr.lst[0].char)
			print('dbg3')
		else:
			print('dbg4')
			if self.ptr.lst[0] is None:
				print('dbg42-returning from pr')
				return()
			print('dbg 45')
			for i in self.ptr.lst:
				i.pr(i)
			print('dbg5')
def factorial(n):
	if n > 1:
		return(n * factorial(n-1))
	else:
		return(1)
input_str=input('Enter an anagram str > ')
input_lst=list(input_str)
print('input str is ',input_str)
input_str_len=len(input_str)
anagram_perms=factorial(input_str_len)
print('The no. of anagram permutations is ',anagram_perms)
anagrams=[[] for i in range(anagram_perms)]
tmplst=list(deepcopy(input_str))
newlen=int(anagram_perms/input_str_len)
row=1
npr=1
head=node(tmplst[0],input_str_len-1)
prevnode=head
print(head.char)
head.pr(head)
print('done with root node')
#
row+=1
npr=input_str_len-1
prevrow=row-1
k=0
for i in tmplst[1:]:
	print(i)
	newnode=node(i,input_str_len-1-1)
	print(newnode.char)
	prevnode.lst[k]=newnode
	k+=1
print('-----')
head.pr(head)
print('-----')
#
k=0
prevrow=row
row+=1
npr=npr*(npr-1)

