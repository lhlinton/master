#!/usr/bin/python3
s='A rat in toms house ate toms ice cream'
tokens=s.split()
tokens.reverse()
for i in range(len(tokens)):
	tokens[i]=tokens[i][::-1]
s=' '.join(i for i in tokens)
print(s)
