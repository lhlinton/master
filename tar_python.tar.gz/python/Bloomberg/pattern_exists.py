#!/usr/bin/python3
import re
s='xabvfabhabzna'
print('string is ',s)
#Min pattern is 2 char substring that repeats at least once
for i in range(len(s)-1):
	x=re.findall(s[i]+s[i+1],s)
	if len(x) > 1:
		print('pattern exists > ',s[i],' ',s[i+1])
