#!/usr/bin/python3
s='great'
v=['a','e', 'i', 'o', 'u', 'y']
i=0
s=list(s)
j=len(s)-1
while i<j:
	while s[i] not in v and i<j:i+=1
	while s[j] not in v and i<j:j-=1
	s[i],s[j]=s[j],s[i]
	i+=1
	j-=1
print(s)
