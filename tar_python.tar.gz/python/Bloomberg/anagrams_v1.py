#!/usr/bin/python3
from collections import deque
def factorial(n):
	if n > 1:
		return(n * factorial(n-1))
	else:
		return(1)
input_str=input('Enter an anagram str > ')
print('input str is ',input_str)
input_str_len=len(input_str)
anagram_perms=factorial(input_str_len)
print('The no. of anagram permutations is ',anagram_perms)
anagrams=[[] for i in range(anagram_perms)]
dq=deque(input_str)
i=0
stop=anagram_perms
start=0
step=input_str_len
while i < input_str_len:
	for j in range(start,stop,step):
		anagrams[j].append(input_str[i])
	i+=1
	start+=1
print(anagrams)
