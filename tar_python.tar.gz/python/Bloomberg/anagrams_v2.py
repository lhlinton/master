#!/usr/bin/python3
from copy import deepcopy
def factorial(n):
	if n > 1:
		return(n * factorial(n-1))
	else:
		return(1)
input_str=input('Enter an anagram str > ')
input_str=list(input_str)
print('input str is ',input_str)
input_str_len=len(input_str)
anagram_perms=factorial(input_str_len)
print('The no. of anagram permutations is ',anagram_perms)
anagrams=[[] for i in range(anagram_perms)]
i=0
while i < input_str_len:
	tmpstr=deepcopy(input_str)
	#tmpstr.pop(0)
	#print(type(tmpstr))
#	anagrams[i].append(input_str[i])
	j=0
	while j < len(tmpstr):
		k=0
		anagrams[j+i*input_str_len].append(tmpstr[i])
		while k < len(tmpstr):
			anagrams[i].append(tmpstr[k])
			print('ijk=',i,j,k)
			print(anagrams)
			k+=1
	#	print(type(tmpstr))
		tmpstr.pop(0)
	#	print(type(tmpstr))
		j+=1
	i+=1
print(anagrams)
