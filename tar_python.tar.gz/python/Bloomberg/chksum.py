#!/usr/bin/python3
#IP HDR CHKSUM
#Sum each 16 bits, then take 1's complement
#
