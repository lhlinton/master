#!/usr/bin/python3
import string
x='lee'
y=2.22222
z=3.33333
print(x,end='    ')
print(''.join(str(elem).ljust(10) for elem in [y,z]))
#tmp='    '.join(str(elem) for elem in [y,z])
#print(tmp)
#print("%0.2f,     ,%0.2f" % (y,z))
