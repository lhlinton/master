#!/usr/bin/python3
import sys
def change(amt):
	chlist=[2000,1000,500,100,25,10,5,1]
	retlist=[]
	denoms=len(chlist)
	amt2=int(100*amt)
	print('amt2=',amt2)
	for i in range(denoms):
		tmp=int(amt2/chlist[i])
		print(tmp)
		tmp2=amt2-(tmp * chlist[i])
		print(tmp2)
		retlist.append(tmp)
		amt2=tmp2
		print(' ')
	print('20 10 5 1 Q D N C')
	for i in range(denoms):
		print(retlist[i],end='  ')
	print(' ')
	print('-----------------------')
	return(retlist)
if len(sys.argv) != 2:
	print('must input amount to be changed...exiting')
	exit()
amt=float(sys.argv[1])
print('Input amount = ',sys.argv[1])
#change(amt)
twenties,tens,fives,ones,quarters,dimes,nickels,cents=change(amt)
print('twenties,tens,fives,ones,quarters,dimes,nickels,cents')
print(twenties,tens,fives,ones,quarters,dimes,nickels,cents)
