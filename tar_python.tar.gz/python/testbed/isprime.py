#!/usr/bin/python3
import re,sys
while True:
	n=int(input('Enter a number to see if it is prime(0 to exit)> '))
	if n == 0:
		exit()
	else:
		print(n)
	for i in range(2,int(n/2)):
		flag=False
		if n % i == 0:
			print(n,i)
			flag=True
			print('NOT prime')
			break
	if flag is True:continue
	else: print('is prime')
