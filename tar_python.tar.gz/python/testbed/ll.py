#!/usr/bin/python3
class LnkNod:
	def __init__(self,num):
		self.num=num
		self.next=None
class LnkLst:
	def __init__(self):
		self.head=None
	def app(self,num):
		newnode=LnkNod(num)
		if self.head is None: self.head=newnode; return()
		nxtptr=self.head
		while nxtptr.next is not None:
			nxtptr=nxtptr.next
		nxtptr.next=newnode
		return()
	def pr(self):
		if self.head is None: print('no list');exit()
		nxtptr=self.head
		while nxtptr is not None:
			print(nxtptr.num,end=' ')
			nxtptr=nxtptr.next
		print(' ')
	def rev(self):
		if self.head is None: print('no list');exit()
		currptr=self.head
		prevptr=None
		nextptr=currptr.next
		while nextptr is not None:
			currptr.next=prevptr
			prevptr=currptr
			currptr=nextptr
			nextptr=currptr.next
		self.head=currptr
		currptr.next=prevptr
n=LnkLst()
n.app(0)
n.pr()
n.app(1)
n.pr()
n.app(2)
n.pr()
n.rev()
n.pr()
nn=LnkLst()
nn.app(10)
nn.pr()
nn.app(11)
nn.pr()
nn.app(12)
nn.pr()
nn.rev()
nn.pr()
