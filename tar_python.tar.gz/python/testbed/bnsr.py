#!/usr/bin/python3
l=input('Enter a space separated list of integers> ').split()
print(l)
lenl=len(l)
for i in range(lenl):
	l[i]=int(l[i])
n=int(input('Enter a number whose index in the sorted list will be returned> '))
print('Your search number is> ',n)
#l=[2,1,6,88,32,0]
print('l=',l)
sl=sorted(l)
print(sl)
print("There are ",lenl," numbers")
mx=lenl-1
mn=0
mid=int((mx-mn)/2)
print('mid=',mid)
