#!/usr/bin/python3
import re
patip=re.compile('ip')
pataddr=re.compile('\d+(\.\d+){3}')
with open('cpuout','r') as f:
	lines=f.read().splitlines()
for line in lines:
	tokens=re.split('\s+',line)
	print('dbg:',tokens[0],tokens[2])
	if re.match(patip,tokens[0]):
		print('ip match')
		if re.match(pataddr,tokens[2]):
			print('ipaddr is ', tokens[2])
			exit()
