#!/usr/bin/python3
import re,sys
s='ssamuel'
print(s)
ls=list(s)
vlst=['a','e','i','o','u']
i=0
j=len(s)-1
k=len(s)
while i < j:
	if ls[i] not in vlst:
		i+=1
		continue
	if ls[j] not in vlst:
		j-=1
		continue
	tmp=ls[i]
	ls[i]=ls[j]
	ls[j]=tmp
	i+=1
	j-=1
print(''.join(ls[i] for i in range(k)))
