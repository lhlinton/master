#!/usr/bin/python3
import re
s='we dont need no education we dont need no thought control no we dont'
print(s)
tokens=re.split('\s+',s)
dlen={i:0 for i in tokens}
dcnt={i:0 for i in tokens}
for i in tokens:
	dlen[i]=len(i)
	dcnt[i]+=1
print('dlen')
print(dlen)
print('dcnt')
print(dcnt)
