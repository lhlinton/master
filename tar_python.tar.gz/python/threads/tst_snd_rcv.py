#!/usr/bin/python3
import datetime,threading
loglck=threading.Lock()
barr=threading.Barrier(2)
def snd(x):
	print('In snd')
	print(x)
	barr.wait()
	for i in range(15):
		ts=str(datetime.datetime.now())
		msg=ts+' '+'SEND '+str(i)+'\n'
		loglck.acquire()
		log.write(msg)
		loglck.release()
def rcv(x):
	print('In rcv')
	print(x)
	barr.wait()
	for i in range(15):
		ts=str(datetime.datetime.now())
		msg=ts+' '+'RECV '+str(i)+'\n'
		loglck.acquire()
		log.write(msg)
		loglck.release()

log=open('tst_thrd_log','w+')
thrd_lst=[]
tsnd=threading.Thread(target=snd,args=('SND',))
trcv=threading.Thread(target=rcv,args=('RCV',))
thrd_lst.append(tsnd)
thrd_lst.append(trcv)
for t in thrd_lst:
	t.start()
print('threads started')
for t in thrd_lst:
	t.join()
print('threads joined')
log.close()
