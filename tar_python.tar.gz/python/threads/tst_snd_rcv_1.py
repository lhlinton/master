#!/usr/bin/python3
import datetime,threading
log=open('tst_thrd_log','w+')
def snd():
	print('In snd')
	for i in range(15):
		ts=str(datetime.datetime.now())
		msg=ts+' '+'SEND '+str(i)+'\n'
		log.write(msg)
def rcv():
	print('In rcv')
	for i in range(15):
		ts=str(datetime.datetime.now())
		msg=ts+' '+'RECV '+str(i)+'\n'
		log.write(msg)
snd()
rcv()
log.close()
