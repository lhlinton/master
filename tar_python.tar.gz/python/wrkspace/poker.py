#!/usr/bin/python3
from random import randrange
import sys
deck=[i for i in range(52)]
suits=['clubs', 'diamonds', 'hearts', 'spades']
face_card=['jack','queen','king','ace']
HAND_CARDS=5
if len(sys.argv) !=2:
	print('Usage: <cmd> <no. of poker hands>')
	exit(1)
nhands=int(sys.argv[1])
print('No. of poker hands = ',nhands)
hand=[[None for i in range(HAND_CARDS)] for j in range(nhands)]
deck_cnt=len(deck)
for i in range(HAND_CARDS):
	for j in range(nhands):
		card_index=deck.pop(randrange(0,len(deck)))
		card_val=card_index % 13
		card_suit=suits[card_index % 4]
		card_val+=2
		if card_val <= 10:
			card_val=str(card_val)
		else:
			card_val=face_card[card_val-11]
		hand[j][i]=[card_val,card_suit]
		hand[j][i]=tuple(hand[j][i])
checkset=set([])
for i in range(nhands):
	print('Hand ',i+1)
	for j in range(HAND_CARDS):
		print(hand[i][j],' ',end=' ')
		checkset.add(hand[i][j])
	print('\n')
print('checkset len = ',len(checkset))
print('HAND_CARDS * nhands = ',HAND_CARDS*nhands)
