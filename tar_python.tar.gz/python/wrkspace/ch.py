#!/usr/bin/python3
import re
ippat=re.compile('ip')
addrpat=re.compile('\d+(\.\d+){3}')
with open('cpout_lhl','r') as f:
	lines=f.read().splitlines()
for l in lines:
	tokens=re.split('\s+',l)
	if re.match(ippat,tokens[0]):
		if re.match(addrpat,tokens[2]):
			print(tokens[2])
		break
