#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from collections import OrderedDict
from operator import itemgetter

indent=''
def do_ls(dir):
	global indent
	indent=indent+'  '
	os.chdir(dir)
	files=subprocess.getoutput('ls -aF')
	flist=re.split('\n',files)
	for f in flist:
		if re.match('\.',f): continue
		print(indent,f)
		if re.search('/$',f): do_ls(f.rstrip('/'))
if len(sys.argv) !=2:print('dir required');exit(0)
do_ls(sys.argv[1])
"""
lee@lee-SMBIOS-UBUNTU:~/python/wrkspace$ ./myoswalk.py .
   binsrch.py*
   card_deals.py*
   ch.py*
   cht.py*
   cpout_lhl
   dest_entr_exit.py*
   destructor.py*
   fib.py*
   get_nos_frm_str.py*
   GOLDxll.py*
   mit_changemaker.py*
   mit_word_index.py*
   myoswalk.py*
   poker.py*
   singleton_logger.py*
   sing_log
   tst_class.py*
   tst_dir/
     f1
     f2
     f3
"""
