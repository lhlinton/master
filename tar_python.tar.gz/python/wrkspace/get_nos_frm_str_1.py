#!/usr/bin/python3
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from collections import OrderedDict
from operator import itemgetter
Usage="Usage: <cmd> <str with consecutive alpha and nums>"
#if len(sys.argv) != 2 : 
#	print(Usage)
#	exit(1)
#arg1=sys.argv[1]
while True:
	try:
		s=input('Enter a str of alphas and nums and sum consec. digits, cntrl-C to exit > ')
		print('input is ',s)
	except:print(' ');exit(0)
	
	alpha='alpha'
	num='num'
	state=alpha
	s=s+'END'
	slen=len(s)
	numlist=[]
	number=''
	sumlist=[]

	for i in range(slen):
		prev_state=state
		if s[i].isdigit():
			state=num
			number=number+s[i]
		else:
			state=alpha
			if prev_state==num: 
				numlist.append(number)
				print(number)
				number=''
			continue
	
	print('numlist is ',numlist)	

	for i in numlist:
		n=len(i)
		sum=0
		for j in i:
			sum+=int(j)
		print(sum)
		
"""
OUTPUT
input is  abvcx1234s2q3w5q987
1234
2
3
5
987
numlist is  ['1234', '2', '3', '5', '987']
10
2
3
5
24
"""
