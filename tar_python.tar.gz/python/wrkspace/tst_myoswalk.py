#!/usr/bin/python3
import subprocess,re
def zls(dir):
	cmd='ls -aF '+dir
	fils=subprocess.getoutput(cmd)
	lines=re.split('\n',fils)
	for line in lines:
		fnames=re.split('\s+',line)
		for f in fnames:
			print(f)
			if f.startswith('.'):continue
			if f.endswith('/'):
				zls(f.rstrip('/'))
zls('.')
