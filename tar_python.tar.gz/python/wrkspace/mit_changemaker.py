#!/usr/bin/python3
import sys
def change(amt):
	bills=[1,5,2,20,10]
	bills=sorted(bills,reverse=True)
	for i in bills:
		n=int(amt/i)
		yield n
		amt-=i*n
amt=int(sys.argv[1])
vals=['twenties','tens','fives','twos','ones']
chlist=change(amt)
chlist=list(chlist)
for i in range(len(chlist)-1):
	if chlist[i] != 0:print(chlist[i],vals[i],',',end=' ')
if chlist[i+1] != 0:
	print(chlist[i+1],vals[i+1])
else:
	print('')
