#!/usr/bin/python3
class Log:
	__exists=False
	def __init__(self):
		print('Log constructor')
		if not Log.__exists:
			Log.log=open('sing_log','w')
			Log.log.write('INITIAL LOG REC\n')
			print('sing_log opened')
			Log.__exists=True
	def WriteLog(self):
		Log.log.write('writing to log\n')
		print('writing to log')
l=Log()
l.WriteLog()
l.WriteLog()
ll=Log()
ll.WriteLog()
ll.WriteLog()
"""OUTPUT
Log constructor
sing_log opened
writing to log
writing to log
Log constructor
writing to log
writing to log
lee@lee-SMBIOS-UBUNTU:~/python/wrkspace$ cat sing_log
INITIAL LOG REC
writing to log
writing to log
writing to log
writing to log
"""
