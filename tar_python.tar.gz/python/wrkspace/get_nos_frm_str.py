#!/usr/bin/python3
import re
	
def sumlist(numlist):
	sum_list=[]
	for i in numlist:
		sum=0
		for j in i:
			sum+=int(j)
		sum_list.append(sum)
	return(sum_list)

def numlist(s):
	pat_num=re.compile('\d+')
	num_list=[]
	return(re.findall(pat_num,s))

while True:
	try:
		s=input('Enter a str of alphas and nums and sum consec. digits, cntrl-C to exit > ')
		print('input is ',s)
	except:print(' ');exit(0)

	num_list=numlist(s)
	print(num_list)
	print(sumlist(num_list))
