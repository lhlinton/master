#!/usr/bin/python3
class A:
    ii=7
    __iii=7
    def __init__(self, i = 0):
        self.i = i

class B(A):
    def __init__(self, j = 0):
        self.j = j

def main():
    b = B()
    print(b.ii)
    print(b.j)
# the 2 lines below both fail
    print(b.__iii)
    print(b.i)

main()
