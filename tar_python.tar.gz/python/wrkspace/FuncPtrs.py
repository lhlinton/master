#!/usr/bin/python3
#
#Look man, no big cache busting switch block
#
def add(n1,n2):return(n1+n2)
def sub(n1,n2):return(n1-n2)
def mul(n1,n2):return(n1*n2)
def div(n1,n2):return(n1/n2)
FuncDict={}
Add,Sub,Mul,Div=range(1,5)
FuncDict[Add]=add
FuncDict[Sub]=sub
FuncDict[Mul]=mul
FuncDict[Div]=div
while True:
	print('Func No: 1-add,2-sub,3,mul,4-div')
	(i,j,k)=input('Enter func no and 2 operands > ').split()
	print(FuncDict[int(i)](int(j),int(k)))
