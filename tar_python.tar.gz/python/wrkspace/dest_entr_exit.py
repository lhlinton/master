#!/usr/bin/python3
class T:
  def __init__(self):
    print('Tinit')
  def __enter__(self):
    print('Entering')
  def pr(self):
    print('msg')
  def __del__(self):
    print('Destructing')
  def __exit__(self,a,b,c):
    print('Exit Destructing')
with T() as zz:
	print('kilroy was here first')
	zz=T()
	print('kilroy was here')
	print(hasattr(zz,'pr'))
	zz.pr()
	print(hasattr(zz,'pr'))
print('done - leaving scope')
"""
Tinit
Entering
kilroy was here first
Tinit
kilroy was here
True
msg
True
Exit Destructing
Destructing
done - leaving scope
Destructing
"""
