#!/usr/bin/python3
import string,re
from collections import defaultdict
d=defaultdict(list)
s='we dont need no education we dont need no thought control no we dont'
tokens=re.split('\s+',s)
for i in range(len(tokens)):
	d[tokens[i]].append(i)
for k,v in d.items():
	print(k,v)
