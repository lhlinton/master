#!/usr/bin/python3
def bs(n,l):
	lo=0;hi=len(l)-1
	if n==l[lo]:return(lo)
	if n==l[hi]:return(hi)
	while hi-lo>1:
		mid=int((hi-lo)/2)+lo
		if l[mid]==n:return(mid)
		if l[mid]<n:lo=mid;continue
		hi=mid
l=[1,3, 4, 6, 8, 10, 15, 20,25]
l=sorted(l)
print('l=',l)
for i in range(len(l)):
	n=l[i]
	print('seeking index of',n)
	print('index=',bs(n,l))
