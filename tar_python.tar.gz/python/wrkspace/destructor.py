#!/usr/bin/python3
class T:
  def __init__(self):
    print('Tinit')
  def __enter__(self):
    print('Entering')
  def pr(self):
    print('msg')
  def __del__(self):
    print('Destructing')
  def __exit__(self,a,b,c):
    print('Exit Destructing')
x=T()
x.pr()
print(hasattr(x,'pr'))
x.__del__()
print(hasattr(x,'pr'))
print('done - leaving scope')
"""
Tinit
msg
True
Destructing
True
done - leaving scope
Destructing
"""
