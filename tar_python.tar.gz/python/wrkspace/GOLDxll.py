#!/usr/bin/python3
class node:
	def __init__(self,v):
		self.n=v
		self.next=None
class ll:
	def __init__(self,v):
		self.head=node(v)
	def app(self,v):
		ptr=self.head
		newnode=node(v)
		while ptr.next:
			ptr=ptr.next
		ptr.next=newnode
	def pr(self):
		ptr=self.head
		while ptr:
			print('val=',ptr.n)
			ptr=ptr.next
	def rev(self):
		prev=None
		ptr=self.head
		while ptr.next:
			nextptr=ptr.next
			ptr.next=prev
			prev=ptr
			ptr=nextptr
		ptr.next=prev
		self.head=ptr
	def setloop(self,v):
		ptr=self.head
		while ptr.next:
			if ptr.n==v:loop_ptr=ptr
			ptr=ptr.next
		ptr.next=loop_ptr
	def isloop(self):
		ptr=self.head
		ptr2=self.head.next
		while True:
			if ptr==ptr2:
				print('loop detected where val=',ptr.n)
				break
			else:
				if not ptr or not ptr2:
					print('no loop found')
					break
			ptr=ptr.next
			ptr2=ptr2.next.next
a=ll(1)
a.app(2)
a.app(3)
a.pr()
a.rev()
a.pr()
b=ll(4)
b.app(5)
b.app(6)
b.pr()
b.rev()
b.pr()
a.isloop()
a.setloop(2)
a.isloop()
"""
val= 1
val= 2
val= 3
val= 3
val= 2
val= 1
val= 4
val= 5
val= 6
val= 6
val= 5
val= 4
no loop found
loop detected where val= 2
"""
