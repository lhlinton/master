#!/usr/bin/python3
def fib(n):
  if n <= 0:print('fib param must be >= 0');return
  yield 0
  if n >= 2:yield 1
  if n==2:return
  a=0;b=1
  for i in range(3,n+1):
    a,b=b,a+b
    yield b
for i in fib(9):print(i,end=' ')
print('')
