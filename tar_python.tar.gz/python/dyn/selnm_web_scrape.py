#!/usr/bin/python3
"""
Because no events were scheduled at the end of the year this assignment
was changed to doing a similar task on the newsroom link. The elements
displayed were the link,page title,article title,author,date, and 
category(Company News). Note that the arguments passed the the webdriver
methods were discovered by reading the relevant web pages at 
https://dyn.com/newsroom.
"""

import os
from selenium import webdriver
os.environ['MOZ_HEADLESS'] = '1'

dyn_url="https://dyn.com/newsroom/"
driver = webdriver.Firefox()
driver.get(dyn_url)
print("web page title: ",driver.title)
urls=driver.find_elements_by_id('panel-read-more')
for index in range(len(urls)):
	print(40*"*")
	urls=driver.find_elements_by_id('panel-read-more')
	print(urls[index].get_attribute("href"))
	driver.get(urls[index].get_attribute("href"))
	print("web page title: ",driver.title)
	elems=driver.find_elements_by_id("hero")
	for el in elems:
		print(el.text)
# Skip refreshing the DOM elements for next loop iteration if this
# is the last iteration.
	if index == len(urls) - 1: break
	driver.get(dyn_url)
	urls=driver.find_elements_by_id('panel-read-more')
print(40*"*")
print('done')
driver.quit()
