#!/usr/bin/python3
from urllib.request import urlopen
import re
#event_sections=urlopen("http://dyn.com/about/events")
#print(events_sections.read())
event_sect_tag=re.compile('<section id="events-section">')
with open('about','r') as ab:
	lines=ab.read().splitlines()
print("lines in the file = ",len(lines))
