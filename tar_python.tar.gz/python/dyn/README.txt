Problem 5:
Because no events were scheduled at the end of the year this assignment
was changed to doing a similar task on the newsroom link. The elements
displayed were the link,page title,article title,author,date, and 
category(Company News).

1. To execute the python script type the filename selnm_web_scrape.py <Ret>

2. Because of the error msg below, stale DOM element, it was necessary to reset 
the DOM by doing a driver.get and driver.find_elements... at the bottom of 
the outer loop.

> stale; either the element is no longer attached to the DOM, it is not in the current frame context, or the document has been refreshed

3. It was very difficult to match all the software components to get this
to run successfully. For example the Mozilla headless option would only
work with Mozilla 55 or greater and I had to upgrade from 49 to 58.
The list is as follows:
Mozilla 58.0
Ubuntu 14.04 i686 32bit
geckodriver 0.18.0
selenium-3.8.0.dist-info
python 3.4

4. The performance on my laptop was extremely poor and was greatly
exacerbated after installing Mozilla 58, both a CPU and MEM hog. Each
run took a long time before the final "done" msg was printed. Please
be patient when running it. The runs were sometimes 5 min. long.

5. Script inline documentation: Because the program was very short (25 lines),
the print statements for web page titles, http links, and elements
belonging to an id are self explanatory, as well as the selenium 
webdriver method names, I felt no comments were necessary.

6. Expected output from running the script on Dec 19 12:00:00 :

lee@lee-SMBIOS-UBUNTU:~/python/dyn$ selnm_web_scrape.py
web page title:  Newsroom - Dyn
****************************************
https://dyn.com/blog/the-value-of-the-oracle-dyn-combination/
web page title:  The Value Of The Oracle + Dyn Combination | Dyn Blog
The Value Of The Oracle + Dyn Combination
Company News // Feb 2, 2017 // Kyle York
****************************************
https://dyn.com/blog/not-cool-89-of-companies-experienced-internet-disruption-in-the-last-year/
web page title:  Not Cool: 89% Of Companies Experienced Internet Disruption In The Last Year | Dyn Blog
Not Cool: 89% Of Companies Experienced Internet Disruption In The Last Year
Company News // Jan 12, 2017 // Trip Kucera
****************************************
https://dyn.com/blog/why-were-excited-to-join-oracle/
web page title:  Why We’re Excited To Join Oracle | Dyn Blog
Why We’re Excited To Join Oracle
Company News // Nov 21, 2016 // Kyle York
****************************************
done
lee@lee-SMBIOS-UBUNTU:~/python/dyn$
