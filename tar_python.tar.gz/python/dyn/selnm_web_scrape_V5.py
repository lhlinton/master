#!/usr/bin/python3
import os,time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
os.environ['MOZ_HEADLESS'] = '1'

dyn_url="https://dyn.com/newsroom/"
driver = webdriver.Firefox()
driver.get(dyn_url)
print(driver.title)
urls=driver.find_elements_by_id('panel-read-more')
for index in range(len(urls)):
	print(40*"*")
	urls=driver.find_elements_by_id('panel-read-more')
	print(urls[index].get_attribute("href"))
	driver.get(urls[index].get_attribute("href"))
	print(driver.title)
	elems=driver.find_elements_by_id("hero")
	for el in elems:
		print(el.text)
	driver.get(dyn_url)
	urls=driver.find_elements_by_id('panel-read-more')
print(40*"*")
print('done')
driver.quit()
