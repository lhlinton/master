#!/usr/bin/python3
#a[href~='://'] 	//a[contains(@href, '://')]
#href="https://dyn.com/events/"
import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
os.environ['MOZ_HEADLESS'] = '1'
#cap = DesiredCapabilities().FIREFOX
#cap["marionette"] = False
#driver = webdriver.Firefox(capabilities=cap)

dyn_url="https://dyn.com/newsroom/"
py_url="http://www.python.org"
driver = webdriver.Firefox()
driver.get(dyn_url)
print("Kilroy was here")
print(driver.title)
newsroom=driver.find_element_by_id('panel-read-more')
print(newsroom.text)
#TypeError: 'FirefoxWebElement' object is not iterable
#for line in newsroom:
#	print(line.text)
#Unable to locate element a
#print(newsroom.find_element_by_css_selector('a').get_attribute('href'))
print(driver.find_element_by_id('panel-read-more').get_attribute("href"))
urls=driver.find_elements_by_id('panel-read-more')
#urls=driver.find_elements_by_id('panel-read-more').get_attribute("href")
print('kilroy was also here')
for link in urls:
	print(link.get_attribute("href"))
#	print(link)
driver.quit()
#assert "Python" in driver.title
