#!/bin/bash
echo "Spawning 5 processes"
for i in {1..5} ;
do
    ( ./tst_login.exp & )
done
