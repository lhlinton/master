#!/usr/bin/python3
import os,time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
os.environ['MOZ_HEADLESS'] = '1'

dyn_url="https://dyn.com/newsroom/"
driver = webdriver.Firefox()
driver.get(dyn_url)
print(driver.title)
#newsroom=driver.find_element_by_id('panel-read-more')
#print(newsroom.text)
urls=driver.find_elements_by_id('panel-read-more')
"""
"> stale; either the element is no longer attached to the DOM, it is not in the current frame context, or the document has been refreshed
"""
for link in urls:
#	driver.get(dyn_url)
	print(driver.title)
#	urls=driver.find_elements_by_id('panel-read-more')
#	driver.get(dyn_url)
	print(link.get_attribute("href"))
	driver.get(link.get_attribute("href"))
	print(driver.title)
	elems=driver.find_elements_by_id("hero")
	print('kilroy was here')
	for el in elems:
		print('lee was here')
		print(el.text)
	driver.back()
#	driver.close()
	time.sleep(10)
print("New stuff")
print('done')
driver.quit()
