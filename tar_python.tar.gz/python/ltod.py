def ListToDict(l):
	d={}
	for k in range(0,len(l),2):
		d.update({l[k]:l[k+1]})
	print(l)
	return d
def DictToList(d):
	l=[]
	for k,v in d.items():
		l.extend([k,v])
	return l
