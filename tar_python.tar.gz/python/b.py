#!/usr/bin/python3
import sys,os,re
class LN:
	def __init__(self,num):
		self.num=num
		self.next=None
class LL:
	def __init__(self):
		self.head=None
	def app(self,num):
		newnode=LN(num)
		if self.head is None : self.head=newnode;return()
		nextptr=self.head
		while nextptr.next is not None:
			nextptr=nextptr.next
		nextptr.next=newnode
		return()
	def pr(self):
		nextptr=self.head
		if nextptr is None:print('headis none');exit(0)
		while nextptr is not None:
			print("nodeval = ",nextptr.num)
			nextptr=nextptr.next
	def rev(self):
		nextptr=self.head
		if nextptr is None:print('headis none');exit(0)
		prevptr=None
		while nextptr is not None:
			tmpptr=nextptr.next
			nextptr.next=prevptr
			prevptr=nextptr
			nextptr=tmpptr
		self.head=prevptr
#n=LL()
#n.app(2)
n=LL.app(2)
n.pr()
exit()
n.app(4)
n.pr()
n.app(6)
n.pr()
print('next obj')
n.rev()
n.pr()
