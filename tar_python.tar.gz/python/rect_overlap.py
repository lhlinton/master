#!/usr/bin/python3
r1=[(0,0),(0,10),(10,10),(10,0)] # square
r2=[(5,7),(5,15),(20,15),(20,7)] # overlaps r1
#r2=[(20,20),(20,40),(40,40),(40,20)] # NO overlaps r1
print('r1=',r1)
print('r2=',r2)
l1x=[]; l2x=[]; l1y=[]; l2y=[]
rpts=4
[l1x.append(r1[i][0]) for i in range(rpts)]
[l2x.append(r2[i][0]) for i in range(rpts)]
[l1y.append(r1[i][1]) for i in range(rpts)]
[l2y.append(r2[i][1]) for i in range(rpts)]
minl1x=min(l1x); minl2x=min(l2x); minl1y=min(l1y); minl2y=min(l2y)
maxl1x=max(l1x); maxl2x=max(l2x); maxl1y=max(l1y); maxl2y=max(l2y)
if (maxl1x < minl2x or maxl2x < minl1x) and (maxl1y < minl2y or maxl2y < minl1y):
	print('NO OVERLAP')
	exit(0)
else:
	print('OVERLAP')
if r1[0][0] > r2[0][0]:
	tmp=r1
	r1=r2
	r2=tmp
print('r1=',r1)
print('r2=',r2)
print('overlap region:')
overl=[]
overl.append((r2[0][0],r2[0][1]))
overl.append((r2[1][0],r1[1][1]))
overl.append((r1[2][0],r1[2][1]))
overl.append((r1[3][0],r2[3][1]))
print(overl)
print('overlap2 region:')
overl2=[]
for i in range(rpts):
	if i == 0:
		p1=max(r1[i][0],r2[i][0])
		p2=max(r1[i][1],r2[i][1])
		overl2.append((p1,p2))
	if i == 1:
		p1=max(r1[i][0],r2[i][0])
		p2=min(r1[i][1],r2[i][1])
		overl2.append((p1,p2))
	if i == 2:
		p1=min(r1[i][0],r2[i][0])
		p2=min(r1[i][1],r2[i][1])
		overl2.append((p1,p2))
	if i == 3:
		p1=min(r1[i][0],r2[i][0])
		p2=max(r1[i][1],r2[i][1])
		overl2.append((p1,p2))
print(overl2)
""" OUTPUT
r1= [(0, 0), (0, 10), (10, 10), (10, 0)]
r2= [(5, 7), (5, 15), (20, 15), (20, 7)]
OVERLAP
r1= [(0, 0), (0, 10), (10, 10), (10, 0)]
r2= [(5, 7), (5, 15), (20, 15), (20, 7)]
overlap region:
[(5, 7), (5, 10), (10, 10), (10, 7)]
overlap2 region:
[(5, 7), (5, 10), (10, 10), (10, 7)]
"""
