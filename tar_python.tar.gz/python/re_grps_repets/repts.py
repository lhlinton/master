#!/usr/bin/python3
import re
c=re.compile('(abc){3,3}')
s='abcdefabcabcdefghiabcabcabc'
q=re.search(c,s)
print(q.group(0))
#output: 'abcabcabc'
