#!/usr/bin/python3
import re
class LnkNode:
	def __init__(self,num):
		self.num=num
		self.next=None
class LnkLst:
	def __init__(self):
		self.head=None
	def app(self,num):
		newnode=LnkNode(num)
		if self.head == None: 
			self.head=newnode
			return()
		nextptr=self.head
		while nextptr.next != None:
			nextptr=nextptr.next
		nextptr.next=newnode
		return()
	def pr(self):
		nextptr=self.head
		while nextptr != None:
			print(nextptr.num)
			nextptr=nextptr.next
		print('--------------')
	def rev(self):
		currptr=self.head
		prevptr=None
		if currptr == None:
			print('no list')
			return()
		while currptr != None:
			tmpptr=currptr.next
			currptr.next=prevptr
			prevptr=currptr
			currptr=tmpptr
		self.head=prevptr
n=LnkLst()
n.app(2)
n.pr()
n.app(7)
n.pr()
n.app(9)
n.pr()
n.rev()
n.pr()
o=LnkLst()
o.app(2)
o.pr()
o.app(7)
o.pr()
o.app(9)
o.pr()
o.rev()
o.pr()
