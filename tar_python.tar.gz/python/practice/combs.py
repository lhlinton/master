#!/usr/local/bin/python3
class CombTree:
	def __init__(self,val):
		self.num=val
		self.next=None
	def factrl(n):
		if n == 0: return(1)
		elif n < 0: 
			print('n must be >= 0, exiting')
			exit()
		else: return(n*factrl(n-1))
	def combinations(n,m):
# n,m -> n things taken m at a time where order is important
		return(int(factrl(n)/factrl(n-m)))
	def getcombs(n,m):
		CombLst=[]
		start=0
		branches=n-1
		depth=1
		while depth < m:
			while branches < n:
			
			
			
(n,m)=input('Enter 2 space separated nums for comb function n things taken m at a time > ').split()
n=int(n)
m=int(m)
print('n,m are ',n,m)
print('ans = ',combinations(n,m))
x=CombTree(0,n,m)
print(getcombs(n,m))
