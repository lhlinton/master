#!/usr/local/bin/python3
def fibo(n):
	fl=[0,1]
	for i in range(2,n):
		fl.append(fl[i-2]+fl[i-1])
	return(fl)
n=int(input('Enter the length of the fibonacci seq. > '))
if n < 1:
	print('invalid value...exiting')
elif n==1:
	print('[0]')
elif n==2:
	print('[0,1]')
else:
	print(fibo(n))
exit()

