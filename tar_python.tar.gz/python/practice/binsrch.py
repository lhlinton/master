#!/usr/local/bin/python3
val=88
l=[2,1,6,88,32,0]
print('l=',l)
sl=sorted(l)
print(sl)
ll=len(l)
mid=round(ll/2)
print(mid)
cnt=0
while val != sl[mid] and cnt < 5:
	cnt+=1
	if val > sl[mid]:
		print('GT,val,mid,sl[mid]',val,mid,sl[mid])
		mid=round((ll-mid)/2) + mid
		print('mid,val GT',mid,val)
	elif val < sl[mid]:
		print('LT,val,mid,sl[mid]',val,mid,sl[mid])
		mid=round(mid/2)
		print('mid,val LT',mid,val)
	else: print('break');break
print('done',mid,val)
