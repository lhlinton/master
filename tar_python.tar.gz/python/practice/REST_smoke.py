#!/usr/bin/python
import requests
url='http://198.159.196.140/monitor_agent/testify'
querystring={'suite':'thingspace-v2','hostname':'nginx-swag2-ts.mon-marathon-service-mesos'}
headers={'cache-control':'no-cache'}
response=('kilroy was here')
response = requests.request("GET",url,headers=headers,params=querystring)
print(response.text)
