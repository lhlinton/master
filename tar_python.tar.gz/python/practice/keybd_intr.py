#!/usr/bin/python
import time,sys
print('START')
while True:
	try:
		print('kilroy was here')
		time.sleep(5)
	except  Exception as e:
		if isinstance(e, KeyboardInterrupt):
			print('exiting...1')
			sys.exit()
#silently catching all exceptions
		pass
print('exiting...2')
sys.exit()

