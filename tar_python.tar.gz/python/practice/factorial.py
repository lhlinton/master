#!/usr/local/bin/python3
def factrl(n):
	if n == 0: return(1)
	elif n < 0: 
		print('n must be >= 0, exiting')
		exit()
	else: return(n*factrl(n-1))
n=int(input('Enter num for factorial function > '))
print('ans = ',factrl(n))
