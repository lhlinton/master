#!/usr/local/bin/python3
from collections import defaultdict
d=defaultdict(int)
dirlist=['D','U','R','L']
d.fromkeys(dirlist)
print('d= ',d)
s=input('Enter a string of U(up) D(down) R(right) L(left) > ')
print('input= ',s)
V=0
H=0
for i in s:
	if i == 'U':V+=1
	elif i == 'D': V-=1
	elif i == 'L': H-=1
	elif i == 'R': H+=1
	else: print('invalid dir...skipping to next token');continue
print('H,V = ',H,V)
d={x:0 for x in dirlist}
dval=[-1,1,1,-1]
dpos=dict(zip(dirlist,dval))
for i in s:
	d[i]+=dpos[i]
print('------------------')
print(d)
H=d['R']+d['L']
V=d['U']+d['D']
print('H,V = ',H,V)
