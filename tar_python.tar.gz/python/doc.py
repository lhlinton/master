#!/usr/bin/python3
#
#Comment program to print usage 
#Example ls *.c *.py | $HOME/doc.py doc.py
#
import re,sys,os
pat_comment=re.compile('Comment')
for filename in sys.stdin:
	lsline=filename[:-1]
	filename=lsline.replace("*","")
	if filename == "a.out":
		continue
	print(filename,end=' - ')
	fil=open(filename,'r')
	for line in fil:
		if pat_comment.search(line):
			words=line.split()
			words[0]=words[0].replace('#\s*',"")
			for x in range(1,len(words)):
				print (words[x],end=' ')
			break
	print(" ")
	fil.close
