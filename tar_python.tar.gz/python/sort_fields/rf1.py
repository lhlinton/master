#!/usr/bin/python3
def result_lst(lst):
	for i in lst:
		print('.'.join(j for j in i[::-1]))
def rev_lsts(lst):
	retlst=[]
	for l in lst:
		retlst.append(list(reversed(l)))
	return(retlst)
def dn2lst(dom_lst):
	l3=[]
	for x in dom_lst:
		l3.append(list(x.strip().split('.')))
	return(l3)
def pr_lst(lst):
	print()
	for i in lst:
		print(i)
def get_input(fn):
	with open(fn,'r') as f:
		dom_lst=f.read().splitlines()
	return(dom_lst)
fn=input('name of input file of domain names to sort> ')
dom_lst=get_input(fn)
pr_lst(dom_lst)
l2=dn2lst(dom_lst)
pr_lst(l2)
l4=rev_lsts(l2)
pr_lst(l4)
print(sorted(l4))
l5=sorted(l4)
print(l5)
print('RESULTS')
result_lst(l5)
