#!/usr/bin/perl -w
sub dn2lst {
	my @tmplst;
	my (@dom_lst)=@_;
	print "STEP 1.5 \n";
	for my $line (@dom_lst) {
		my @tmplst2;
		push(@tmplst2,split(/\./,$line));
		print(@tmplst2);
		print "\n";
		push(@tmplst,@tmplst2);
		print(@tmplst);
		print "\n";
		}
	return @tmplst;
	}
sub pr_lst {
	my (@dom_lst)=@_;
	foreach my $line (@dom_lst) {
		print "$line \n";
		}
	}
sub get_input {
	my ($fn)=@_;
	open(FN,$fn) or die("no file in current directory \n");
	my @dom_lst;
	while (<FN>) {
		chomp $_;
		$_ =~ s/^\s+|\s+$//g;
		print "$_ \n";
		push(@dom_lst,$_)
		}
	close(FN);
	return @dom_lst;
	}
print "name of input file of domain names to sort> ";
chomp (my $fn=<STDIN>);
print "$fn \n";
my @dom_lst=get_input($fn);
print "STEP1\n";
pr_lst(@dom_lst);
my @tmplst=dn2lst(@dom_lst);
print "STEP2 \n";
pr_lst(@tmplst);
