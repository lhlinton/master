#!/usr/bin/python3
from collections import OrderedDict
from operator import itemgetter
d={'e': 1, 'c': 5, 'b': 23, 'd': 17, 'a': 2}
dsrtkey=OrderedDict(sorted(d.items(),key=itemgetter(0)))
dsrtval=OrderedDict(sorted(d.items(),key=itemgetter(1)))
print(dsrtkey)
print(dsrtval)
