#!/usr/bin/python3
import re,os,sys
def fib2(n):
	old=1;sum=2
	if n <= 2:return(2)
	for i in range(3,n):
		tmp=sum
		sum+=old
		old=tmp
	return(sum)
def fib(n):
	if n < 2: return(1)
	return (fib(n-1) + fib(n-2))
n=int(input('Enter fibonacci seq. no.> '))
print(fib(n-1))
print(fib2(n))
