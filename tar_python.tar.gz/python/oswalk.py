#!/usr/bin/python3
import os,re,sys
for root,dirs,files in os.walk('../OO'):
	for name in files:print(os.path.join(root,name))
	for name in dirs:print(os.path.join(root,name))
