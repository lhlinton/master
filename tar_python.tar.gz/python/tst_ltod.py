#!/usr/bin/python3
import re,os,sys
from ltod import ListToDict,DictToList
l=['a',2,'b',4]
print(l)
print("calling...")
d=ListToDict(l)
print(d)
print('done')
dd={'x':45,'y':33,'z':11}
print(dd)
l=DictToList(dd)
print(l)
