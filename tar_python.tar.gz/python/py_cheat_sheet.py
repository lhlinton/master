#!/usr/bin/python3
import re,os,os.path,sys,subprocess
patip=re.compile('ip')
cat_cmd=str(subprocess.getoutput('cat cpout_lhl'))
#print(cat_cmd)
cat_lines=re.split('\n',cat_cmd)
for line in range(0,len(cat_lines)) :
	cat_tokens=re.split('\s+',cat_lines[line])
	if re.match(patip, cat_tokens[0]) :
	# if patip == cat_tokens[0] :
		print(cat_tokens[0],'  ',cat_tokens[2])
		patipadd=re.compile('\d+\.\d+\.\d+\.\d+')
		patipadd2=re.compile('\d+(\.\d+){3}')
		if re.match(patipadd,cat_tokens[2]) :
			print(cat_tokens[2])
		if re.match(patipadd2,cat_tokens[2]) :
			print(cat_tokens[2])
		exit()
