#!/usr/bin/python3
# Get the largest num in a stack using class stack
import random
import re,os,sys,string,os.path
import collections,subprocess
from functools import reduce
from collections import OrderedDict
from operator import itemgetter
class stack():
	def __init__(self,depth):
		self.stack=[]
		for i in range(depth):
			self.stack.append(random.randrange(1,100))
		print('initial stack=',self.stack)
	def pop(self):
		self.stack.pop()
		print('popped stack=',self.stack)
	def push(self,num):
		self.stack.append(num)
		print('pushed stack=',self.stack)
	def stackmax(self):
		return(max(self.stack))
n=int(input('Enter the number of elems in the stack> '))
s=stack(n)
s.pop()
s.push(5555)
print('stackmax=',s.stackmax())
""" OUTPUT
Enter the number of elems in the stack> 10
initial stack= [62, 43, 99, 50, 80, 92, 49, 21, 46, 63]
popped stack= [62, 43, 99, 50, 80, 92, 49, 21, 46]
pushed stack= [62, 43, 99, 50, 80, 92, 49, 21, 46, 5555]
stackmax= 5555
"""
