#!/usr/bin/python
import re
patp=re.compile('^processor')
patc=re.compile('^core id')
pats=re.compile('^siblings')
pats_num=re.compile('\d$')
nprcs=0
ncors=0
nsibs=0
sibs_val=[]
sibs_tot=0
fil=open('/proc/cpuinfo','r')
for line in fil: 
	line = line[:-1]
	if patp.match(line):
		nprcs+=1
		print line
	elif patc.match(line):
		ncors+=1
		print line
	elif pats.match(line):
		sibs_val = re.split(': ',line)
		sibs_tot += int(sibs_val[1])
		nsibs+=1
		print line
print "processors=",nprcs,"core ids=",ncors,"siblings=",nsibs,"total siblings=",sibs_tot
if sibs_tot == ncors * 2: print 'hyperthreading enabled'
elif sibs_tot == ncors: print 'hyperthreading not enabled'
else: print 'hyperthreading anomaly, need to check'
