#!/usr/bin/python3
import re,subprocess,os,tempfile,sys
def rewrite_wo_cntrlM(filename):
	with tempfile.NamedTemporaryFile(delete=False) as tmp:
		for line in open(filename):
			line = line.rstrip()
			tmp.write(bytes(line + '\n','UTF-8'))
		os.rename(filename, filename + '.bak')
		os.rename(tmp.name, filename)
		print("DEBUG REWRITE: ",filename)
def osw(lsaF,n):
# The list below is not ascii, lines do not end with ^M, and cannot
# be wriiten with UTF-8 to a file
	UnicodeDecodeErrorList=['suo','msi','exe','pdb','class','docx','db','backup','zip','dll','gif','doc','jpg','jar','ppt','png','eap','cw']
	n+=1
	for l in re.split('\n',lsaF):
		print((n*' '),l)
		if l.rstrip('/') == '.' or l.rstrip('/') == '..' : continue
		if re.split('\.',l)[-1] in UnicodeDecodeErrorList : continue
		if l.startswith('lhl') : continue
# There is something wrong with the ascii file below
# BAD at end of last line no ^M and no endofline - ReaderApplicationBM/ReaderApplicationBM/Properties/AssemblyInfo.cs
# OK - SyncService/SyncWS/SyncWS/Properties/AssemblyInfo.cs
# Above files dealt with manually after this script executed
		if l == 'AssemblyInfo.cs' : continue
		l=os.getcwd()+'/'+l
		if l.endswith('/'):
			os.chdir(l)
			cmd="ls -aF "
			osw(subprocess.getoutput(cmd),n)
			os.chdir('..')
		else:
			rewrite_wo_cntrlM(l)
	return()
if len(sys.argv) != 2 or sys.argv[1][0] != '/':
	print('Usage: <cmd> <full path to dir>')
	exit()
os.chdir(sys.argv[1])
cmd='ls -aF '+sys.argv[1]
osw(subprocess.getoutput(cmd),1)
print(' ..done')
