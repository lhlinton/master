#!/usr/bin/python3
import socket,threading,sys,re,datetime,select

if(len(sys.argv) < 3) :
	print('Usage : <cmd> <clnt_ip:port> <clnt_id> e.g. chat_clnt.py 127.0.0.1:5000 c1')
	sys.exit()
RCVBUF_LEN=4096
CLIENT=sys.argv[2]
RADDR=sys.argv[1]
HOST=re.split(':',RADDR)[0]
PORT=int(re.split(':',RADDR)[1])
EXIT_FLAG=False
LOGNAME=CLIENT+'_LOG'

sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = (HOST, PORT)
print("Connecting to server")
sckt.connect((HOST, PORT))
loglck=threading.Lock()
barr=threading.Barrier(2)
sock_conns=[sckt]

def snd():
	global EXIT_FLAG
	barr.wait()
	while True:
		message = input('To send >')
		if not message: message='bye'
		sndmsg=CLIENT + ': ' + message
		sckt.send(sndmsg.encode())
		print('Sent ' ,sndmsg)
		ts=str(datetime.datetime.now())
		logmsg=ts+' '+sndmsg+'\n'
		loglck.acquire()
		log.write(logmsg)
		loglck.release()
		if message == 'exit' or message == 'bye' or message == 'quit': 
			EXIT_FLAG=True
			break

def rcv():
	global EXIT_FLAG
	barr.wait()
	while True:
		rds,wrs,errs=select.select(sock_conns,[],[],2.0)
		if EXIT_FLAG: break
		if not rds:continue
		rcvmsg=sckt.recv(RCVBUF_LEN).decode()
		if not rcvmsg:continue
		#if not rcvmsg:break
		print('Received ',rcvmsg)
		ts=str(datetime.datetime.now())
		logmsg=ts+' '+rcvmsg+'\n'
		loglck.acquire()
		log.write(logmsg)
		loglck.release()

log=open(LOGNAME,'w+',encoding='utf-8')
thrd_lst=[]
tsnd=threading.Thread(target=snd)
trcv=threading.Thread(target=rcv)
thrd_lst.append(tsnd)
thrd_lst.append(trcv)
for t in thrd_lst:
  t.start()
print('threads started')
for t in thrd_lst:
  t.join()
print('threads joined')
sckt.close()
print("Connection closed")
log.seek(0)
for line in log.read().splitlines(): print(line)
log.close()
