#!/usr/bin/python3
import select,socket,datetime

META_ADDR_LIST='0.0.0.0'
PORT=5000
MAXCLIENTS=6
RCVBUF_LEN=4096
connections = []
#
# NOTE: python3 uses utf-8 as default for encode/decode which solves the
#        unicode issue of Chinese characters in the assignment
#

def send_all(message):
    for connection in connections:
        num_bytes=connection.send(message.encode()) 
        print('-------------')
        print('DBG NUMBYTES ',num_bytes)
        print('DBG CONN ',connection)
        print("Sending %s" % message)
        print('-------------')


# Set up the listening socket
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sckt.bind((META_ADDR_LIST,PORT))
sckt.listen(MAXCLIENTS)

# Accept connections in a loop
while True:
    print("Waiting for message")
    readable, writable, errored = select.select([sckt] + connections,[],[])
    print('recvd message')

    for connection in readable:
        if connection == sckt:
            print("New connection received")
            connection, address = sckt.accept()
            print('DEBUGC ',type(connection))
            print("DEBUGCONN=",connection)
            print("DEBUGADDR=",address)
            connections.append(connection)
            print('DBGSET ',connections)
        else:
            # A message has been sent or the connection is closed
            message = connection.recv(RCVBUF_LEN).decode()
            if not message:
                print("Connection closed")
                connections.remove(connection)
            else:
                timestamp=datetime.datetime.now()
                logmsg=str(timestamp) + ' ' + message
                print("Message received: %s" % logmsg)
                send_all(logmsg)

