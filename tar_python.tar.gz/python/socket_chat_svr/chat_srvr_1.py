#!/usr/bin/python3
import select
import socket
import datetime

META_ADDR_LIST='0.0.0.0'
PORT=5000
MAXCLIENTS=3
connections = set()

# NOTE: python3 uses utf-8 as default for encode/decode

def send_all(message):
    for connection in connections:
        print("Sending %s" % message)
        connection.send(message.encode()) 


# Set up the listening socket
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sckt.bind((META_ADDR_LIST,PORT))
sckt.listen(MAXCLIENTS)

# Accept connections in a loop
while True:
    print("Waiting for any change")
    (readable, writable, errored) = select.select([sckt] + list(connections), [], [])

    for connection in readable:
        # If it's the main socket, then it's a new connection, otherwise it's a new message
        if connection == sckt:
            print("New connection received")
            (connection, address) = sckt.accept()
            print('DEBUGC ',type(connection))
            print("DEBUGCONN=",connection)
            print("DEBUGADDR=",address)
            connections.add(connection)
            print('DBGSET ',connections)
        else:
            # A message has been sent to us or the connection is closed
            message = connection.recv(1024).decode()
            if not message:
                print("Connection closed")
                connections.remove(connection)
            else:
                timestamp=datetime.datetime.now()
                logmsg=str(timestamp) + ' ' + message
                print("Message received: %s" % logmsg)
                send_all(message)

