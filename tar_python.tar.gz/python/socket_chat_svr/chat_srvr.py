#!/usr/bin/python3
import select,socket,datetime,os,re

META_ADDR_LIST='0.0.0.0'
PORT=5000
MAXCLIENTS=6
RCVBUF_LEN=4096
connections = []
client_conn_dict={}
clnt_fil_obj_dict={}
CLIENT_NUM=0

#
# NOTE: python3 uses utf-8 as default for encode/decode which solves the
#        unicode issue of Chinese characters in the assignment
#

def print_log(fil_obj):
	fil_obj.seek(0)
	for l in fil_obj.read().splitlines(): print(l)

def send_all(message,clnt):
	for cl,connection in client_conn_dict.items():
		if clnt == cl: continue
		num_bytes=connection.send(message.encode()) 

# Set up the listening socket
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sckt.bind((META_ADDR_LIST,PORT))
sckt.listen(MAXCLIENTS)

# Accept connections in a loop
while True:
	print("Waiting for message")
	readable, writable, errored = select.select([sckt] + connections,[],[])
	print('recvd message')

	for connection in readable:
		if connection == sckt:
			print("New connection received")
			connection, address = sckt.accept()
			connections.append(connection)
			CLIENT_NUM+=1
			clnt='c'+str(CLIENT_NUM)
			clnt_msg=clnt+' joined'
			fd=os.open('log'+str(CLIENT_NUM),os.O_RDWR|os.O_TRUNC|os.O_CREAT)
			fo=os.fdopen(fd,'w+',encoding='utf-8')
			clnt_fil_obj_dict[clnt]=fo
			ts=str(datetime.datetime.now())
			log_msg=ts+' '+clnt_msg+'\n'
			send_all(clnt_msg,'c0') #c0 => send all connections(clnt dict not updated yet)
			fo.write(log_msg)
			client_conn_dict[clnt]=connection
			print('DEBUGC ',type(connection))
			print("DEBUGCONN=",connection)
			print("DEBUGADDR=",address)
			print('DBGSET ',connections)
		else:
			# A message has been sent or the connection is closed
			message = connection.recv(RCVBUF_LEN).decode()
			clnt=re.split(':',message)[0].strip()
			clnt_msg=re.split(':',message)[1].strip()
			timestamp=datetime.datetime.now()
			log_msg=str(timestamp) + ' ' + message+'\n'
			fo=clnt_fil_obj_dict[clnt]
			fo.write(log_msg)
			send_all(clnt_msg,clnt) # omit sending to clnt
			if clnt_msg == 'quit' or message == 'bye' or message == 'exit':
				print("Connection closed")
				print_log(fo)
				client_conn_dict.pop(clnt,None)
				clnt_fil_obj_dict.pop(clnt,None)
				connections.remove(connection)
			else:
				print('Message received ', clnt_msg)

