#!/usr/bin/python3
import datetime,os
clnt_fil_obj_dict={}
fd=os.open("ts.txt",os.O_RDWR|os.O_TRUNC)
fo=os.fdopen(fd,'w+',encoding='utf-8')
for i in range(10):
	ts=str(datetime.datetime.now())+' '+str(i)+'\n'
	fo.write(ts)
clnt_fil_obj_dict[1]=fo
ko=clnt_fil_obj_dict[1]
ko.seek(0)
for l in ko.read().splitlines():print(l)


