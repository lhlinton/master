#!/usr/bin/python
import select
import socket

connections = set()


def send_all(message):
    for connection in connections:
        print "Sending %s" % message
        connection.send(message)


# Set up the listening socket
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sckt.bind(('0.0.0.0', 9999))
sckt.listen(10)

# We must accept connections in a loop
while True:
    print "Waiting for any change"
    (readable, writable, errored) = select.select([sckt] + list(connections), [], [])

    for connection in readable:
        # If it's the main socket, then it's a new connection, otherwise it's a new message
        if connection == sckt:
            print "New connection received"
            (connection, address) = sckt.accept()
            print connection
            connections.add(connection)
            print connections
        else:
            # A message has been sent to us or the connection is closed
            message = connection.recv(1024)
            if not message:
                print "Connection closed"
                connections.remove(connection)
            else:
                print "Message received: %s" % message
                send_all(message)

