#!/usr/bin/python
import socket

sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('127.0.0.1', 9999)

print "Connecting to server"
sckt.connect(('127.0.0.1', 9999))
while True:
    message = raw_input('To send >')
    sckt.send(message)
    print "Sent %s" % message
    print "Received %s" % sckt.recv(1024)


print "Connection closed"

