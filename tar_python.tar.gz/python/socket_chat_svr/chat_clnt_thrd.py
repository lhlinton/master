#!/usr/bin/python
import socket
import threading

connections = set()


def send_all(message):
    for connection in connections:
        print "Sending %s" % message
        connection.send(message)


def receive(connection):
    while True:
        print "Waiting for message"
        message = connection.recv(1024)
        if not message:
            print "Closing connection and removing from registry"
            connections.remove(connection)
            return
        print "Received %s, sending to all" % message
        send_all(message)


# Set up the listening socket
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sckt.bind(('0.0.0.0', 9999))
sckt.listen(10)

# We must accept connections in a loop
while True:
    print "Waiting for a connection"
    (connection, address) = sckt.accept()
    print "Connection received. Adding to registry"
    connections.add(connection)
    print "Spawning receiver"
    threading.Thread(target = receive, args=[connection]).start()

