#!/usr/bin/python3
import socket

HOST='127.0.0.1'
PORT=5000
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = (HOST, PORT)

print("Connecting to server")
sckt.connect((HOST, PORT))
while True:
    message = input('To send >')
# if not message do something
    if not message or message == 'exit' or message == 'bye': break
    sckt.send(message.encode())
    print("Sent %s" % message)
    print("Received %s" % sckt.recv(1024).decode())
sckt.close()
print("Connection closed")
