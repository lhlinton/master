#!/usr/bin/python3
import socket,threading

HOST='127.0.0.1'
PORT=5000
RCVBUF_LEN=4096
sckt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = (HOST, PORT)

print("Connecting to server")
sckt.connect((HOST, PORT))
while True:
	message = input('To send >')
	if not message: message='bye'
	sckt.send(message.encode())
	if message == 'exit' or message == 'bye': 
		break
	print("Sent %s" % message)
	print("Received %s" % sckt.recv(RCVBUF_LEN).decode())
sckt.close()
print("Connection closed")
