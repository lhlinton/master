#!/usr/bin/python3
import random
class NODE:
	def __init__(self,val):
		self.num=val
		self.next=None
class LLST:
	def __init__(self,ranstart,ranend):
		self.node_val=random.randrange(ranstart,ranend)
		newnode=NODE(self.node_val)
		self.head=newnode
	def pr(self):
		nodeptr=self.head
		count=0
		while nodeptr != None:
			count+=1
			print('nodeval=',nodeptr.num)
			nodeptr=nodeptr.next
		print('node count=',count)
	def add(self,num):
		nodeptr=self.head
		while nodeptr.next is not None:
			nodeptr=nodeptr.next
		nodeptr.next=NODE(num)
	def rev(self):
		nodeptr=self.head
		prevptr=None;
		while nodeptr is not None:
			nextptr=nodeptr.next
			nodeptr.next=prevptr
			prevptr=nodeptr
			nodeptr=nextptr
		self.head=prevptr
l=LLST(1,100)
l.add(2)
l.add(4)
l.add(6)
l.pr()
print('')
l.rev()
l.pr()
print('')
m=LLST(101,200)
m.add(20)
m.add(40)
m.add(60)
m.add(80)
m.pr()
print('')
m.rev()
m.pr()
print('')
