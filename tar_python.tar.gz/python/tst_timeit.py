#!/usr/bin/python3
# Time is float secs
import timeit
setup = """
def getperms(l,l2,depth,count):
	k=range(len(l))
	k2=len(l2)
	if k2 == depth:
		getperms.count+=1
		print('**********RESULT:',getperms.count,l2)
		l2.pop()
		return()
	for i in l:
		if i not in l2:
			l2.append(i)
			getperms(l,l2,depth,count)
	if len(l2) > 0:l2.pop()
def mymain():
	l2=[]
	trees=5;depth=2
	l=[i for i in range(1,trees+1)]
	getperms.count=0
	getperms(l,l2,depth,getperms.count)
"""
t=timeit.Timer("stmt=mymain()",setup=setup)
print(t.timeit(5),' secs')
