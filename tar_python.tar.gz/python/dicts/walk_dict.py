#!/usr/bin/python3
import json
d={
    'SomeRootDirectory': {
        'foo.txt': 'foot',
        'bar.txt': 'bart',
        'Stories': {
            'Horror': {
                'rickscott.txt' : 'rst',
                'Trash' : {
                    'notscary.txt' : 'nst',
                    },
                },
            'Cyberpunk' : 'cp'
            },
        'Poems' : {
            'doyoureadme.txt' : 'dyt'
        }
    }
}
def walk(d,indent):
	indent+=2
	for k,v in d.items():
		print(indent*' ','{',k,':',end='')
		if isinstance(v,dict): 
			print('',end='\n')
			walk(v,indent)
		else: 
			print(v,end='')
			print(indent*' ','}')
	print('\n',indent*' ','}')
a={}
print(json.dumps(d))
with open('jas_dmp','w') as jsd:
	json.dump(d,jsd)
with open('jas_dmp','r') as jsl:
	a=json.load(jsl)
print('\n',a,end='\n\n')
walk(a,0)
