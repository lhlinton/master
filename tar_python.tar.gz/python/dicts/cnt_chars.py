#!/usr/bin/python3
import re,string
def WordLens(sentence):
	WordLen=[]
	Words=re.split('\s+',sentence)
	for w in Words:
		WordLen.append(len(w))
	print(WordLen)
	AnsFormat=' '.join(str(wdelem) for wdelem in WordLen)
	print(AnsFormat)
WordLens("This is a short sentence.")
