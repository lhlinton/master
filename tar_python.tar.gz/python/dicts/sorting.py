>>> class Student:
        def __init__(self, name, grade, age):
            self.name = name
            self.grade = grade
            self.age = age
        def __repr__(self):
            return repr((self.name, self.grade, self.age))

>>>

>>> student_objects = [
    Student('john', 'A', 15),
    Student('jane', 'B', 12),
    Student('dave', 'B', 10),
]
>>> sorted(student_objects, key=lambda student: student.age)   # sort by age
[('dave', 'B', 10), ('jane', 'B', 12), ('john', 'A', 15)]

>>> from operator import itemgetter, attrgetter

>>>

>>> sorted(student_tuples, key=itemgetter(2))
[('dave', 'B', 10), ('jane', 'B', 12), ('john', 'A', 15)]

>>>

>>> sorted(student_objects, key=attrgetter('age'))
[('dave', 'B', 10), ('jane', 'B', 12), ('john', 'A', 15)]

The operator module functions allow multiple levels of sorting. For example, to sort by grade then by age:
>>>

>>> sorted(student_tuples, key=itemgetter(1,2))
[('john', 'A', 15), ('dave', 'B', 10), ('jane', 'B', 12)]

>>>

>>> sorted(student_objects, key=attrgetter('grade', 'age'))
[('john', 'A', 15), ('dave', 'B', 10), ('jane', 'B', 12)]

use param reverse=True for descending sort

>>> sorted(student_tuples, key=itemgetter(2), reverse=True)
[('john', 'A', 15), ('jane', 'B', 12), ('dave', 'B', 10)]

>>>

>>> sorted(student_objects, key=attrgetter('age'), reverse=True)
[('john', 'A', 15), ('jane', 'B', 12), ('dave', 'B', 10)]


>>> from collections import OrderedDict
>>> l=[2,4,77,33,200,0,1]
>>> ll=sorted(l)
>>> ll
[0, 1, 2, 4, 33, 77, 200]
>>> d={'a':55,'b':44,'c':100,'g':1,'d':0}
>>> k=collections.OrderedDict(d)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'collections' is not defined
>>> k=OrderedDict(d)
>>> k
OrderedDict([('b', 44), ('c', 100), ('g', 1), ('d', 0), ('a', 55)])
>>> k=OrderedDict(sorted(d.items))
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'builtin_function_or_method' object is not iterable
>>> k=OrderedDict(sorted(d.items()))
>>> k
OrderedDict([('a', 55), ('b', 44), ('c', 100), ('d', 0), ('g', 1)])
>>> dd=sorted(d.items())
>>> dd
[('a', 55), ('b', 44), ('c', 100), ('d', 0), ('g', 1)]
