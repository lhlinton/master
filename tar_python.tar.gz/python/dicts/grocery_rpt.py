#!/usr/bin/python3
#
# Assumption: with sales tax of 9.25%, an item with
#   cost/revenue of $10.00 has part of that taxed at
#   the rate of .0925% applied to the shelf price
#   i.e. cost=$10.00=(shelf price)*1.0925, which implies
#   shelf price=cost/tax_rate
#   tax_component=cost-shelf price=cost-(cost/1.0925)
#
#
import re
from collections import defaultdict
class LogColumn:
	CustName,ProdCat,ItemDesc,Cost=range(4)
with open('logfile','r') as grocery_log:
	lines=grocery_log.read().splitlines()
dtr=defaultdict(float)
cs=defaultdict(float)
TaxRate=.0925
TaxRateMultiplier=TaxRate+1.0
for i in range(len(lines)):
	print(lines[i])
	tokens=re.split('\|',lines[i])
	namecat=tokens[LogColumn.CustName]+'    '+tokens[LogColumn.ProdCat]
	cs[namecat]+=float(tokens[LogColumn.Cost])
	dtr[tokens[LogColumn.CustName]]+=float(tokens[LogColumn.Cost])
print(' ')
print(dtr)
print(' ')
print(cs)
print(' ')
print('Total revenue by customer:')
print('Customer Name   Cost($)   Sales Tax Component($)')
for k,v in dtr.items():
	print(k,end='         ')
	print("    %0.2f"%(v),end='     ')
	print("    %0.2f"%(v-(v/TaxRateMultiplier)))
print(' ')
max_category_len=15
print('Customer spending by product category:')
print('Customer Category        Cost($)      Sales Tax Component($)')
pad1=25
pad2=20
for k,v in cs.items():
	tmpbuf="%0.2f,%0.2f" % (v,v-(v/TaxRateMultiplier))
	tmpbuf=re.split(',',tmpbuf)
	print(k.ljust(pad1),tmpbuf[0].ljust(pad2),tmpbuf[1].ljust(pad2))
