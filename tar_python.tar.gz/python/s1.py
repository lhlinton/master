#!/usr/bin/python
# Hello world python program
print "Hello World!";
import os
os.system("date")
f = os.popen('date')
now = f.read()
print "Today is ", now,

import subprocess
p = subprocess.Popen("date", stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
print "Today is", output,

p = subprocess.Popen(["ls", "-l", "/etc/resolv.conf"], stdout=subprocess.PIPE)
output, err = p.communicate()
print "*** Running ls -l command ***\n", output,
