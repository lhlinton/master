#!/usr/bin/python3
import sys
amt=float(input('Enter the amount for change> '))
n=int(100*amt)
changelist=[1000,500,100,50,25,10,5,1]
chnames=['tens','fives','ones','half-dollars','quarters','dimes','nickels','pennies']
print(chnames)
change=[]
newn=n
for i in range(len(changelist)):
	q=(int(newn/changelist[i]))
	change.append(q)
	newn-=q*changelist[i]
print(change)
