#!/usr/bin/python3
import sys
if len(sys.argv) != 2:print('Enter the number of ints to check for primes');exit(0)
n=int(sys.argv[1])
for i in range(2,n+1):
	isprime=True
	for j in range(2,i):
		if i % j == 0:isprime=False;break
	if isprime:
		print(i,'is a prime')
	else:
		print(i,'is not a prime')
