#!/usr/bin/python3
def fac(n):
	if n == 0 or n == 1:return(1)
	return(n*fac(n-1))
def perms(n,m):
	return(int(fac(n)/fac(n-m)))
def getperms(l,l2,depth):
	global count
	k=range(len(l))
	k2=len(l2)
	if k2 == depth:
		count+=1
		print('**********RESULT:',count,l2)
		l2.pop()
		return()
	for i in l:
		if i not in l2:
			l2.append(i)
			#print('DEBUG1:',i,l2,len(l2))
			getperms(l,l2,depth)
			#print('DEBUG2:',i,l2,len(l2))
	if len(l2) > 0:l2.pop()
i=5;j=3
print('n,m,perms=',i,j,perms(i,j))
i=4;j=3
print('n,m,perms=',i,j,perms(i,j))
i=6;j=3
print('n,m,perms=',i,j,perms(i,j))
i=4;j=2
print('n,m,perms=',i,j,perms(i,j))
trees=4;depth=2
l=[i for i in range(1,trees+1)]
print(l)
count=0
l2=[]
depth=2
getperms(l,l2,depth)
